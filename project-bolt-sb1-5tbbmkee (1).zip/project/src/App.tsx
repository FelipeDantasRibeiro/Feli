import React, { useState } from 'react';
import { Header } from './components/Layout/Header';
import { Dashboard } from './components/Dashboard/Dashboard';
import { CharacterForm } from './components/CharacterForm/CharacterForm';
import { Backup } from './components/Backup/Backup';
import { Settings } from './components/Settings/Settings';
import { Campaigns } from './components/Campaigns/Campaigns';
import { useCharacters } from './hooks/useCharacters';
import { useSettings } from './hooks/useSettings';
import { useCampaigns } from './hooks/useCampaigns';
import { Character } from './types/character';

type Page = 'dashboard' | 'characters' | 'backup' | 'settings' | 'campaigns' | 'character-form';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [editingCharacter, setEditingCharacter] = useState<Character | null>(null);
  
  const {
    characters,
    addCharacter,
    updateCharacter,
    deleteCharacter,
    exportCharacters,
    importCharacters,
  } = useCharacters();
  
  const { settings, updateSettings } = useSettings();
  const { campaigns, addCampaign, updateCampaign, deleteCampaign } = useCampaigns();

  const handlePageChange = (page: string) => {
    setCurrentPage(page as Page);
    if (page !== 'character-form') {
      setEditingCharacter(null);
    }
  };

  const handleCreateCharacter = () => {
    setEditingCharacter(null);
    setCurrentPage('character-form');
  };

  const handleEditCharacter = (character: Character) => {
    setEditingCharacter(character);
    setCurrentPage('character-form');
  };

  const handleSaveCharacter = (characterData: Omit<Character, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (editingCharacter) {
      updateCharacter(editingCharacter.id, characterData);
    } else {
      addCharacter(characterData);
    }
    setCurrentPage('dashboard');
    setEditingCharacter(null);
  };

  const handleDeleteCharacter = (id: string) => {
    if (window.confirm('Tem certeza que deseja excluir esta ficha?')) {
      deleteCharacter(id);
    }
  };

  const handleCancelForm = () => {
    setCurrentPage('dashboard');
    setEditingCharacter(null);
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return (
          <Dashboard
            characters={characters}
            onCreateCharacter={handleCreateCharacter}
            onEditCharacter={handleEditCharacter}
            onDeleteCharacter={handleDeleteCharacter}
          />
        );
        
      case 'character-form':
        return (
          <CharacterForm
            character={editingCharacter || undefined}
            onSave={handleSaveCharacter}
            onCancel={handleCancelForm}
          />
        );
        
      case 'backup':
        return (
          <Backup
            onExport={exportCharacters}
            onImport={importCharacters}
            charactersCount={characters.length}
          />
        );
        
      case 'settings':
        return (
          <Settings
            settings={settings}
            onUpdateSettings={updateSettings}
          />
        );
        
      case 'campaigns':
        return (
          <Campaigns
            campaigns={campaigns}
            onAddCampaign={addCampaign}
            onUpdateCampaign={updateCampaign}
            onDeleteCampaign={deleteCampaign}
          />
        );
        
      default:
        return (
          <Dashboard
            characters={characters}
            onCreateCharacter={handleCreateCharacter}
            onEditCharacter={handleEditCharacter}
            onDeleteCharacter={handleDeleteCharacter}
          />
        );
    }
  };

  return (
    <div 
      className={`min-h-screen transition-all duration-300 ${
        settings.theme === 'dark' 
          ? 'bg-gradient-to-br from-black via-gray-900 to-gray-800' 
          : 'bg-gradient-to-br from-gray-100 via-white to-gray-200'
      }`}
      style={{
        fontSize: settings.fontSize === 'small' ? '14px' : 
                 settings.fontSize === 'large' ? '18px' : '16px'
      }}
    >
      <Header 
        currentPage={currentPage} 
        onPageChange={handlePageChange}
        settings={settings}
      />
      {renderCurrentPage()}
    </div>
  );
}

export default App;