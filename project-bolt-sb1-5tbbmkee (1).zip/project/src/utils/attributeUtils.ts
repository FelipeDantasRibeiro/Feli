import { DICE_LEVELS } from '../data/diceLevels';
import { AttributeCalculation, TestResult, CharacterAttribute, Skill, VitalMultiplier } from '../types/character';

export const getAttributeLevelFromValue = (value: number): number => {
  for (const level of DICE_LEVELS) {
    if (value >= level.minRange && value <= level.maxRange) {
      return level.level;
    }
  }
  return 1; // Default para valores muito baixos
};

export const getDiceFromValue = (value: number): string => {
  for (const level of DICE_LEVELS) {
    if (value >= level.minRange && value <= level.maxRange) {
      return level.dice;
    }
  }
  return '1d20'; // Default
};

export const calculateAttribute = (
  baseValue: number,
  standardMultiplier: number,
  abilityMultiplier: number
): AttributeCalculation => {
  const afterStandard = baseValue + (baseValue * standardMultiplier / 100);
  const total = afterStandard + (afterStandard * abilityMultiplier / 100);
  
  return {
    baseValue,
    standardMultiplier,
    abilityMultiplier,
    total: Math.floor(total)
  };
};

export const calculateCharacterLevel = (attributes: Record<string, any>): number => {
  const attributeValues = Object.values(attributes);
  if (attributeValues.length === 0) return 1;
  
  const totalLevels = attributeValues.reduce((sum, attr: any) => {
    return sum + (attr.attributeLevel || 1);
  }, 0);
  
  return Math.floor(totalLevels / attributeValues.length);
};

export const calculateVitals = (
  attributes: Record<string, CharacterAttribute>,
  skills: Skill[] = [],
  vitalMultipliers: VitalMultiplier[] = []
) => {
  const constitution = attributes['Constituição']?.calculation.total || 0;
  const strengthLevel = attributes['Força']?.attributeLevel || 1;
  const magicLevel = attributes['Magia']?.attributeLevel || 1;
  const intelligenceLevel = attributes['Inteligência']?.attributeLevel || 1;
  
  const baseVitals = {
    hp: 10 + constitution,
    stamina: 5 + strengthLevel,
    mana: 5 + magicLevel,
    sanity: 20 + intelligenceLevel
  };

  // Aplicar multiplicadores ativos
  const activeMultipliers = vitalMultipliers.filter(m => m.isActive);
  
  const finalVitals = { ...baseVitals };
  
  activeMultipliers.forEach(multiplier => {
    let sourceValue = 0;
    
    if (multiplier.baseSource === 'skill') {
      const skill = skills.find(s => s.name === multiplier.sourceTarget);
      sourceValue = skill?.total || 0;
    } else if (multiplier.baseSource === 'attribute') {
      const attribute = attributes[multiplier.sourceTarget];
      sourceValue = attribute?.calculation.total || 0;
    }
    
    const baseVital = baseVitals[multiplier.targetVital];
    
    if (multiplier.multiplierType === 'percentage') {
      const bonus = Math.floor((sourceValue * multiplier.value) / 100);
      finalVitals[multiplier.targetVital] = baseVital + bonus;
    } else {
      // Tipo fixo
      finalVitals[multiplier.targetVital] = baseVital + multiplier.value;
    }
  });
  
  return finalVitals;
};

export const rollAttributeTest = (attributeValue: number, dice: string): TestResult => {
  const diceSize = parseInt(dice.split('d')[1]);
  const roll = Math.floor(Math.random() * diceSize) + 1;
  
  const target = attributeValue;
  const success = roll <= target;
  
  let level: TestResult['level'];
  
  if (roll >= diceSize * 0.95) {
    level = 'extreme_failure'; // 95%+ = falha extrema
  } else if (!success) {
    level = 'failure';
  } else if (roll <= target * 0.05) {
    level = 'critical'; // 5% do atributo = crítico
  } else if (roll <= target * 0.25) {
    level = 'extreme'; // 25% do atributo = extremo
  } else if (roll <= target * 0.5) {
    level = 'good'; // 50% do atributo = bom
  } else {
    level = 'normal'; // Sucesso normal
  }
  
  return {
    roll,
    target,
    success,
    level
  };
};