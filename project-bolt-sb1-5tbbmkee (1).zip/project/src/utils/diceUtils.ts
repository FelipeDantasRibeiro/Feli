import { DICE_LEVELS } from '../data/diceLevels';
import { AttributeCalculation } from '../types/character';

export const rollDice = (diceLevel: number): number => {
  const level = DICE_LEVELS.find(d => d.level === diceLevel);
  if (!level) return 1;
  
  const diceSize = parseInt(level.dice.split('d')[1]);
  return Math.floor(Math.random() * diceSize) + 1;
};

export const calculateAttribute = (
  base: number,
  standardMultiplier: number,
  abilityMultiplier: number
): AttributeCalculation => {
  const afterStandard = base + (base * standardMultiplier / 100);
  const total = afterStandard + (afterStandard * abilityMultiplier / 100);
  
  return {
    base,
    standardMultiplier,
    abilityMultiplier,
    total: Math.floor(total)
  };
};