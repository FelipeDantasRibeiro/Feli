import React, { useState } from 'react';
import { Skill, CharacterAttribute } from '../../types/character';
import { Plus, Trash2, Target } from 'lucide-react';
import { rollAttributeTest } from '../../utils/attributeUtils';

interface SkillsTabProps {
  skills: Skill[];
  attributes: Record<string, CharacterAttribute>;
  onUpdateSkills: (skills: Skill[]) => void;
}

export const SkillsTab: React.FC<SkillsTabProps> = ({ skills, attributes, onUpdateSkills }) => {
  const [newSkillName, setNewSkillName] = useState('');
  const [newSkillAttribute, setNewSkillAttribute] = useState('Força');

  const addSkill = () => {
    if (newSkillName.trim()) {
      const newSkill: Skill = {
        name: newSkillName.trim(),
        baseAttribute: newSkillAttribute,
        bonus: 0,
        total: attributes[newSkillAttribute]?.calculation.total || 0
      };
      
      onUpdateSkills([...skills, newSkill]);
      setNewSkillName('');
    }
  };

  const updateSkill = (index: number, updates: Partial<Skill>) => {
    const updatedSkills = skills.map((skill, i) => {
      if (i === index) {
        const updated = { ...skill, ...updates };
        // Recalcular total se mudou atributo base ou bônus
        if (updates.baseAttribute || updates.bonus !== undefined) {
          updated.total = (attributes[updated.baseAttribute]?.calculation.total || 0) + updated.bonus;
        }
        return updated;
      }
      return skill;
    });
    onUpdateSkills(updatedSkills);
  };

  const removeSkill = (index: number) => {
    onUpdateSkills(skills.filter((_, i) => i !== index));
  };

  const testSkill = async (skill: Skill) => {
    const baseAttribute = attributes[skill.baseAttribute];
    if (baseAttribute) {
      const result = rollAttributeTest(skill.total, baseAttribute.dice);
      alert(`Teste de ${skill.name}: ${result.roll}/${skill.total} - ${result.success ? 'SUCESSO' : 'FALHA'}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Adicionar Nova Perícia */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-bold text-red-100 mb-4">Adicionar Nova Perícia</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <input
            type="text"
            value={newSkillName}
            onChange={(e) => setNewSkillName(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addSkill()}
            className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
            placeholder="Nome da perícia..."
          />
          
          <select
            value={newSkillAttribute}
            onChange={(e) => setNewSkillAttribute(e.target.value)}
            className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
          >
            {Object.keys(attributes).map(attr => (
              <option key={attr} value={attr}>{attr}</option>
            ))}
          </select>
          
          <button
            onClick={addSkill}
            className="flex items-center justify-center space-x-2 px-4 py-2 bg-red-700 hover:bg-red-600 text-white rounded-lg transition-colors duration-200"
          >
            <Plus className="w-4 h-4" />
            <span>Adicionar</span>
          </button>
        </div>
      </div>

      {/* Lista de Perícias */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {skills.map((skill, index) => (
          <div key={index} className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-lg font-bold text-red-100">{skill.name}</h4>
              <button
                onClick={() => removeSkill(index)}
                className="text-red-400 hover:text-red-300 transition-colors duration-200"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-gray-400 mb-1">Atributo Base</label>
                  <select
                    value={skill.baseAttribute}
                    onChange={(e) => updateSkill(index, { baseAttribute: e.target.value })}
                    className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-sm focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  >
                    {Object.keys(attributes).map(attr => (
                      <option key={attr} value={attr}>{attr}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-xs text-gray-400 mb-1">Bônus</label>
                  <input
                    type="number"
                    value={skill.bonus}
                    onChange={(e) => updateSkill(index, { bonus: parseInt(e.target.value) || 0 })}
                    className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-center focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  />
                </div>
              </div>
              
              <div className="text-center">
                <div className="text-sm text-gray-400 mb-1">Valor Total</div>
                <div className="text-2xl font-bold text-red-400 font-mono mb-3">
                  {skill.total}
                </div>
                
                <button
                  onClick={() => testSkill(skill)}
                  className="flex items-center justify-center space-x-2 w-full py-2 px-4 bg-blue-700 hover:bg-blue-600 text-white rounded-lg transition-colors duration-200"
                >
                  <Target className="w-4 h-4" />
                  <span>Testar</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};