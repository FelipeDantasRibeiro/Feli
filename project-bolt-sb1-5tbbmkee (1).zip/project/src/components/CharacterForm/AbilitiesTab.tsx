import React, { useState } from 'react';
import { ActiveAbility, MultiplierAbility, CharacterAttribute } from '../../types/character';
import { Plus, Trash2, Power, PowerOff, Percent, Zap } from 'lucide-react';

interface AbilitiesTabProps {
  activeAbilities: ActiveAbility[];
  multiplierAbilities: MultiplierAbility[];
  attributes: Record<string, CharacterAttribute>;
  onUpdateActiveAbilities: (abilities: ActiveAbility[]) => void;
  onUpdateMultiplierAbilities: (abilities: MultiplierAbility[]) => void;
  onUpdateAttributes: (attributes: Record<string, CharacterAttribute>) => void;
}

export const AbilitiesTab: React.FC<AbilitiesTabProps> = ({ 
  activeAbilities,
  multiplierAbilities,
  attributes, 
  onUpdateActiveAbilities,
  onUpdateMultiplierAbilities,
  onUpdateAttributes 
}) => {
  const [activeTab, setActiveTab] = useState<'multiplier' | 'normal'>('multiplier');
  
  const [newMultiplierAbility, setNewMultiplierAbility] = useState({
    name: '',
    description: '',
    cost: '',
    percentage: 0,
    targetAttribute: 'Força',
  });

  const [newActiveAbility, setNewActiveAbility] = useState({
    name: '',
    description: '',
    cost: '',
    actionCost: '',
    type: 'active' as 'active' | 'passive' | 'conditional',
  });

  // Funções para Habilidades com Multiplicador
  const addMultiplierAbility = () => {
    if (newMultiplierAbility.name.trim()) {
      const ability: MultiplierAbility = {
        name: newMultiplierAbility.name.trim(),
        description: newMultiplierAbility.description.trim(),
        cost: newMultiplierAbility.cost.trim(),
        percentage: newMultiplierAbility.percentage,
        targetAttribute: newMultiplierAbility.targetAttribute,
        isActive: false
      };
      
      onUpdateMultiplierAbilities([...multiplierAbilities, ability]);
      setNewMultiplierAbility({ name: '', description: '', cost: '', percentage: 0, targetAttribute: 'Força' });
    }
  };

  const updateMultiplierAbility = (index: number, updates: Partial<MultiplierAbility>) => {
    const updatedAbilities = multiplierAbilities.map((ability, i) => 
      i === index ? { ...ability, ...updates } : ability
    );
    onUpdateMultiplierAbilities(updatedAbilities);
  };

  const removeMultiplierAbility = (index: number) => {
    onUpdateMultiplierAbilities(multiplierAbilities.filter((_, i) => i !== index));
  };

  const toggleMultiplierAbility = (index: number) => {
    const ability = multiplierAbilities[index];
    const newIsActive = !ability.isActive;
    
    updateMultiplierAbility(index, { isActive: newIsActive });
    
    // Aplicar ou remover multiplicador
    const updatedAttributes = { ...attributes };
    const targetAttr = updatedAttributes[ability.targetAttribute];
    
    if (targetAttr) {
      const currentAbilityMult = targetAttr.calculation.abilityMultiplier;
      const newAbilityMult = newIsActive 
        ? currentAbilityMult + ability.percentage 
        : currentAbilityMult - ability.percentage;
      
      // Recalcular atributo
      const newCalculation = {
        ...targetAttr.calculation,
        abilityMultiplier: newAbilityMult
      };
      
      const afterStandard = newCalculation.baseValue + (newCalculation.baseValue * newCalculation.standardMultiplier / 100);
      const total = afterStandard + (afterStandard * newCalculation.abilityMultiplier / 100);
      newCalculation.total = Math.floor(total);
      
      updatedAttributes[ability.targetAttribute] = {
        ...targetAttr,
        calculation: newCalculation
      };
      
      onUpdateAttributes(updatedAttributes);
    }
  };

  // Funções para Habilidades Normais
  const addActiveAbility = () => {
    if (newActiveAbility.name.trim()) {
      const ability: ActiveAbility = {
        name: newActiveAbility.name.trim(),
        description: newActiveAbility.description.trim(),
        cost: newActiveAbility.cost.trim(),
        actionCost: newActiveAbility.actionCost.trim(),
        type: newActiveAbility.type,
        isActive: false
      };
      
      onUpdateActiveAbilities([...activeAbilities, ability]);
      setNewActiveAbility({ name: '', description: '', cost: '', actionCost: '', type: 'active' });
    }
  };

  const updateActiveAbility = (index: number, updates: Partial<ActiveAbility>) => {
    const updatedAbilities = activeAbilities.map((ability, i) => 
      i === index ? { ...ability, ...updates } : ability
    );
    onUpdateActiveAbilities(updatedAbilities);
  };

  const removeActiveAbility = (index: number) => {
    onUpdateActiveAbilities(activeAbilities.filter((_, i) => i !== index));
  };

  const toggleActiveAbility = (index: number) => {
    updateActiveAbility(index, { isActive: !activeAbilities[index].isActive });
  };

  return (
    <div className="space-y-6">
      {/* Tabs para Tipos de Habilidades */}
      <div className="border-b border-gray-700">
        <nav className="flex space-x-8">
          <button
            onClick={() => setActiveTab('multiplier')}
            className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors duration-200 flex items-center space-x-2 ${
              activeTab === 'multiplier'
                ? 'border-red-500 text-red-400'
                : 'border-transparent text-gray-400 hover:text-gray-300 hover:border-gray-300'
            }`}
          >
            <Percent className="w-4 h-4" />
            <span>Habilidades com Multiplicador</span>
            <span className="ml-2 bg-gray-700 text-gray-300 py-1 px-2 rounded-full text-xs">
              {multiplierAbilities.length}
            </span>
          </button>
          
          <button
            onClick={() => setActiveTab('normal')}
            className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors duration-200 flex items-center space-x-2 ${
              activeTab === 'normal'
                ? 'border-red-500 text-red-400'
                : 'border-transparent text-gray-400 hover:text-gray-300 hover:border-gray-300'
            }`}
          >
            <Zap className="w-4 h-4" />
            <span>Habilidades Normais</span>
            <span className="ml-2 bg-gray-700 text-gray-300 py-1 px-2 rounded-full text-xs">
              {activeAbilities.length}
            </span>
          </button>
        </nav>
      </div>

      {/* Conteúdo das Tabs */}
      {activeTab === 'multiplier' && (
        <div className="space-y-6">
          {/* Adicionar Habilidade com Multiplicador */}
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <div className="flex items-center space-x-3 mb-4">
              <Percent className="w-6 h-6 text-purple-400" />
              <h3 className="text-lg font-bold text-red-100">Adicionar Habilidade com Multiplicador</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <input
                type="text"
                value={newMultiplierAbility.name}
                onChange={(e) => setNewMultiplierAbility(prev => ({ ...prev, name: e.target.value }))}
                className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder="Nome da habilidade..."
              />
              
              <input
                type="text"
                value={newMultiplierAbility.cost}
                onChange={(e) => setNewMultiplierAbility(prev => ({ ...prev, cost: e.target.value }))}
                className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder="Gasto (ex: 10 MP, 1 Turno)..."
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <select
                value={newMultiplierAbility.targetAttribute}
                onChange={(e) => setNewMultiplierAbility(prev => ({ ...prev, targetAttribute: e.target.value }))}
                className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
              >
                {Object.keys(attributes).map(attr => (
                  <option key={attr} value={attr}>{attr}</option>
                ))}
              </select>
              
              <div className="flex items-center space-x-2">
                <input
                  type="number"
                  value={newMultiplierAbility.percentage}
                  onChange={(e) => setNewMultiplierAbility(prev => ({ ...prev, percentage: parseInt(e.target.value) || 0 }))}
                  className="flex-1 bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  placeholder="0"
                />
                <span className="text-gray-400">%</span>
              </div>
            </div>
            
            <textarea
              value={newMultiplierAbility.description}
              onChange={(e) => setNewMultiplierAbility(prev => ({ ...prev, description: e.target.value }))}
              rows={3}
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none mb-4"
              placeholder="Descrição da habilidade..."
            />
            
            <button
              onClick={addMultiplierAbility}
              className="flex items-center space-x-2 px-4 py-2 bg-purple-700 hover:bg-purple-600 text-white rounded-lg transition-colors duration-200"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Habilidade</span>
            </button>
          </div>

          {/* Lista de Habilidades com Multiplicador */}
          <div className="space-y-4">
            {multiplierAbilities.map((ability, index) => (
              <div key={index} className={`bg-gray-800 rounded-lg p-6 border-2 transition-all duration-200 ${
                ability.isActive ? 'border-purple-600 bg-purple-900/10' : 'border-gray-700'
              }`}>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <Percent className="w-5 h-5 text-purple-400" />
                    <h4 className="text-lg font-bold text-red-100">{ability.name}</h4>
                    <button
                      onClick={() => toggleMultiplierAbility(index)}
                      className={`flex items-center space-x-1 px-3 py-1 rounded-full text-sm font-medium transition-colors duration-200 ${
                        ability.isActive 
                          ? 'bg-purple-700 text-purple-100 hover:bg-purple-600' 
                          : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                      }`}
                    >
                      {ability.isActive ? <Power className="w-3 h-3" /> : <PowerOff className="w-3 h-3" />}
                      <span>{ability.isActive ? 'Ativa' : 'Inativa'}</span>
                    </button>
                  </div>
                  
                  <button
                    onClick={() => removeMultiplierAbility(index)}
                    className="text-red-400 hover:text-red-300 transition-colors duration-200"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div className="bg-gray-700 rounded-lg p-3">
                    <div className="text-xs text-gray-400 mb-1">Atributo Alvo</div>
                    <div className="text-sm font-medium text-gray-200">{ability.targetAttribute}</div>
                  </div>
                  
                  <div className="bg-gray-700 rounded-lg p-3">
                    <div className="text-xs text-gray-400 mb-1">Multiplicador</div>
                    <div className="text-sm font-medium text-purple-400">+{ability.percentage}%</div>
                  </div>
                  
                  <div className="bg-gray-700 rounded-lg p-3">
                    <div className="text-xs text-gray-400 mb-1">Gasto</div>
                    <div className="text-sm font-medium text-gray-200">{ability.cost || 'Nenhum'}</div>
                  </div>
                </div>
                
                {ability.description && (
                  <p className="text-gray-400 text-sm">{ability.description}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'normal' && (
        <div className="space-y-6">
          {/* Adicionar Habilidade Normal */}
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <div className="flex items-center space-x-3 mb-4">
              <Zap className="w-6 h-6 text-blue-400" />
              <h3 className="text-lg font-bold text-red-100">Adicionar Habilidade Normal</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <input
                type="text"
                value={newActiveAbility.name}
                onChange={(e) => setNewActiveAbility(prev => ({ ...prev, name: e.target.value }))}
                className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder="Nome da habilidade..."
              />
              
              <select
                value={newActiveAbility.type}
                onChange={(e) => setNewActiveAbility(prev => ({ ...prev, type: e.target.value as any }))}
                className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
              >
                <option value="active">Ativa</option>
                <option value="passive">Passiva</option>
                <option value="conditional">Condicional</option>
              </select>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <input
                type="text"
                value={newActiveAbility.cost}
                onChange={(e) => setNewActiveAbility(prev => ({ ...prev, cost: e.target.value }))}
                className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder="Gasto (ex: 15 MP, 2 Stamina)..."
              />
              
              <input
                type="text"
                value={newActiveAbility.actionCost}
                onChange={(e) => setNewActiveAbility(prev => ({ ...prev, actionCost: e.target.value }))}
                className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder="Ação gasta (ex: 1 Ação, Reação)..."
              />
            </div>
            
            <textarea
              value={newActiveAbility.description}
              onChange={(e) => setNewActiveAbility(prev => ({ ...prev, description: e.target.value }))}
              rows={3}
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none mb-4"
              placeholder="Descrição da habilidade..."
            />
            
            <button
              onClick={addActiveAbility}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-700 hover:bg-blue-600 text-white rounded-lg transition-colors duration-200"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Habilidade</span>
            </button>
          </div>

          {/* Lista de Habilidades Normais */}
          <div className="space-y-4">
            {activeAbilities.map((ability, index) => (
              <div key={index} className={`bg-gray-800 rounded-lg p-6 border-2 transition-all duration-200 ${
                ability.isActive ? 'border-blue-600 bg-blue-900/10' : 'border-gray-700'
              }`}>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <Zap className="w-5 h-5 text-blue-400" />
                    <h4 className="text-lg font-bold text-red-100">{ability.name}</h4>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      ability.type === 'active' ? 'bg-green-700 text-green-100' :
                      ability.type === 'passive' ? 'bg-yellow-700 text-yellow-100' :
                      'bg-orange-700 text-orange-100'
                    }`}>
                      {ability.type === 'active' ? 'Ativa' : 
                       ability.type === 'passive' ? 'Passiva' : 'Condicional'}
                    </span>
                    <button
                      onClick={() => toggleActiveAbility(index)}
                      className={`flex items-center space-x-1 px-3 py-1 rounded-full text-sm font-medium transition-colors duration-200 ${
                        ability.isActive 
                          ? 'bg-blue-700 text-blue-100 hover:bg-blue-600' 
                          : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                      }`}
                    >
                      {ability.isActive ? <Power className="w-3 h-3" /> : <PowerOff className="w-3 h-3" />}
                      <span>{ability.isActive ? 'Ativa' : 'Inativa'}</span>
                    </button>
                  </div>
                  
                  <button
                    onClick={() => removeActiveAbility(index)}
                    className="text-red-400 hover:text-red-300 transition-colors duration-200"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div className="bg-gray-700 rounded-lg p-3">
                    <div className="text-xs text-gray-400 mb-1">Gasto</div>
                    <div className="text-sm font-medium text-gray-200">{ability.cost || 'Nenhum'}</div>
                  </div>
                  
                  <div className="bg-gray-700 rounded-lg p-3">
                    <div className="text-xs text-gray-400 mb-1">Ação Gasta</div>
                    <div className="text-sm font-medium text-gray-200">{ability.actionCost || 'Nenhuma'}</div>
                  </div>
                </div>
                
                {ability.description && (
                  <p className="text-gray-400 text-sm">{ability.description}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};