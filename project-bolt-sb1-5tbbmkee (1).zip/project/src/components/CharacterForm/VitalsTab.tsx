import React from 'react';
import { CharacterAttribute, Skill, VitalMultiplier } from '../../types/character';
import { Heart, Zap, Sparkles, Brain, Plus, Minus, Settings, Trash2, Power, PowerOff } from 'lucide-react';
import { calculateVitals } from '../../utils/attributeUtils';
import { useState } from 'react';

interface VitalsTabProps {
  attributes: Record<string, CharacterAttribute>;
  skills: Skill[];
  vitals: {
    hp: { current: number; max: number };
    stamina: { current: number; max: number };
    mana: { current: number; max: number };
    sanity: { current: number; max: number };
  };
  vitalMultipliers: VitalMultiplier[];
  onUpdateVitals: (vitals: {
    hp: { current: number; max: number };
    stamina: { current: number; max: number };
    mana: { current: number; max: number };
    sanity: { current: number; max: number };
  }) => void;
  onUpdateVitalMultipliers: (multipliers: VitalMultiplier[]) => void;
}

export const VitalsTab: React.FC<VitalsTabProps> = ({ 
  attributes, 
  skills, 
  vitals, 
  vitalMultipliers,
  onUpdateVitals,
  onUpdateVitalMultipliers 
}) => {
  const [showMultipliers, setShowMultipliers] = useState(false);
  const [newMultiplier, setNewMultiplier] = useState({
    name: '',
    description: '',
    cost: '',
    targetVital: 'hp' as 'hp' | 'stamina' | 'mana' | 'sanity',
    multiplierType: 'percentage' as 'percentage' | 'fixed',
    value: 0,
    baseSource: 'skill' as 'skill' | 'attribute',
    sourceTarget: skills.length > 0 ? skills[0].name : 'Força',
  });

  const calculatedVitals = calculateVitals(attributes, skills, vitalMultipliers);

  const addVitalMultiplier = () => {
    if (newMultiplier.name.trim()) {
      const multiplier: VitalMultiplier = {
        ...newMultiplier,
        name: newMultiplier.name.trim(),
        description: newMultiplier.description.trim(),
        cost: newMultiplier.cost.trim(),
        isActive: false
      };
      
      onUpdateVitalMultipliers([...vitalMultipliers, multiplier]);
      setNewMultiplier({
        name: '',
        description: '',
        cost: '',
        targetVital: 'hp',
        multiplierType: 'percentage',
        value: 0,
        baseSource: 'skill',
        sourceTarget: skills.length > 0 ? skills[0].name : 'Força',
      });
    }
  };

  const updateVitalMultiplier = (index: number, updates: Partial<VitalMultiplier>) => {
    const updatedMultipliers = vitalMultipliers.map((multiplier, i) => 
      i === index ? { ...multiplier, ...updates } : multiplier
    );
    onUpdateVitalMultipliers(updatedMultipliers);
  };

  const removeVitalMultiplier = (index: number) => {
    onUpdateVitalMultipliers(vitalMultipliers.filter((_, i) => i !== index));
  };

  const toggleVitalMultiplier = (index: number) => {
    updateVitalMultiplier(index, { isActive: !vitalMultipliers[index].isActive });
  };

  const updateVital = (type: 'hp' | 'stamina' | 'mana', field: 'current' | 'max', value: number) => {
    const newVitals = {
      ...vitals,
      [type]: {
        ...vitals[type],
        [field]: Math.max(0, value)
      }
    };
    
    // Garantir que current não seja maior que max
    if (field === 'max' && newVitals[type].current > value) {
      newVitals[type].current = value;
    }
    
    onUpdateVitals(newVitals);
  };

  const adjustVital = (type: 'hp' | 'stamina' | 'mana', amount: number) => {
    const newCurrent = Math.max(0, Math.min(vitals[type].max, vitals[type].current + amount));
    updateVital(type, 'current', newCurrent);
  };

  const recalculateMaxVitals = () => {
    // Recalcular com multiplicadores ativos
    const newCalculatedVitals = calculateVitals(attributes, skills, vitalMultipliers);
    
    const newVitals = {
      hp: { 
        current: Math.min(vitals.hp.current, newCalculatedVitals.hp), 
        max: newCalculatedVitals.hp 
      },
      stamina: { 
        current: Math.min(vitals.stamina.current, newCalculatedVitals.stamina), 
        max: newCalculatedVitals.stamina 
      },
      mana: { 
        current: Math.min(vitals.mana.current, newCalculatedVitals.mana), 
        max: newCalculatedVitals.mana 
      },
      sanity: { 
        current: Math.min(vitals.sanity.current, newCalculatedVitals.sanity), 
        max: newCalculatedVitals.sanity 
      }
    };
    onUpdateVitals(newVitals);
  };

  const getPercentage = (current: number, max: number) => {
    return max > 0 ? (current / max) * 100 : 0;
  };

  const getBarColor = (percentage: number, type: 'hp' | 'stamina' | 'mana') => {
    if (type === 'hp') {
      if (percentage > 75) return 'bg-green-500';
      if (percentage > 50) return 'bg-yellow-500';
      if (percentage > 25) return 'bg-orange-500';
      return 'bg-red-500';
    } else if (type === 'stamina') {
      return 'bg-blue-500';
    } else if (type === 'mana') {
      return 'bg-purple-500';
    } else {
      return 'bg-indigo-500';
    }
  };

  return (
    <div className="space-y-6">
      {/* Botão para Recalcular */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-bold text-red-100 mb-2">Recalcular Vitais</h3>
            <p className="text-gray-400 text-sm">
              Atualiza os valores máximos baseados nos atributos e multiplicadores ativos
            </p>
          </div>
          <button
            onClick={recalculateMaxVitals}
            className="px-6 py-3 bg-red-700 hover:bg-red-600 text-white rounded-lg font-semibold transition-colors duration-200"
          >
            Recalcular
          </button>
        </div>
        
        <div className="flex items-center justify-between pt-4 border-t border-gray-700">
          <div>
            <h4 className="text-md font-semibold text-red-100 mb-1">Multiplicadores de Vitais</h4>
            <p className="text-gray-400 text-sm">
              Adicione bônus baseados em perícias ou atributos
            </p>
          </div>
          <button
            onClick={() => setShowMultipliers(!showMultipliers)}
            className="flex items-center space-x-2 px-4 py-2 bg-purple-700 hover:bg-purple-600 text-white rounded-lg transition-colors duration-200"
          >
            <Settings className="w-4 h-4" />
            <span>{showMultipliers ? 'Ocultar' : 'Gerenciar'}</span>
          </button>
        </div>
      </div>

      {/* Seção de Multiplicadores */}
      {showMultipliers && (
        <div className="space-y-6">
          {/* Adicionar Multiplicador */}
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <h3 className="text-lg font-bold text-red-100 mb-4">Adicionar Multiplicador de Vital</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <input
                type="text"
                value={newMultiplier.name}
                onChange={(e) => setNewMultiplier(prev => ({ ...prev, name: e.target.value }))}
                className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder="Nome do multiplicador..."
              />
              
              <input
                type="text"
                value={newMultiplier.cost}
                onChange={(e) => setNewMultiplier(prev => ({ ...prev, cost: e.target.value }))}
                className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder="Gasto (ex: 10 MP, Passivo)..."
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
              <select
                value={newMultiplier.targetVital}
                onChange={(e) => setNewMultiplier(prev => ({ ...prev, targetVital: e.target.value as any }))}
                className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
              >
                <option value="hp">HP</option>
                <option value="stamina">Stamina</option>
                <option value="mana">Mana</option>
                <option value="sanity">Sanidade</option>
              </select>
              
              <select
                value={newMultiplier.baseSource}
                onChange={(e) => {
                  const source = e.target.value as 'skill' | 'attribute';
                  setNewMultiplier(prev => ({ 
                    ...prev, 
                    baseSource: source,
                    sourceTarget: source === 'skill' 
                      ? (skills.length > 0 ? skills[0].name : 'Atletismo')
                      : 'Força'
                  }));
                }}
                className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
              >
                <option value="skill">Perícia</option>
                <option value="attribute">Atributo</option>
              </select>
              
              <select
                value={newMultiplier.sourceTarget}
                onChange={(e) => setNewMultiplier(prev => ({ ...prev, sourceTarget: e.target.value }))}
                className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
              >
                {newMultiplier.baseSource === 'skill' 
                  ? skills.map(skill => (
                      <option key={skill.name} value={skill.name}>{skill.name}</option>
                    ))
                  : Object.keys(attributes).map(attr => (
                      <option key={attr} value={attr}>{attr}</option>
                    ))
                }
              </select>
              
              <select
                value={newMultiplier.multiplierType}
                onChange={(e) => setNewMultiplier(prev => ({ ...prev, multiplierType: e.target.value as any }))}
                className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
              >
                <option value="percentage">Porcentagem</option>
                <option value="fixed">Valor Fixo</option>
              </select>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="flex items-center space-x-2">
                <input
                  type="number"
                  value={newMultiplier.value}
                  onChange={(e) => setNewMultiplier(prev => ({ ...prev, value: parseInt(e.target.value) || 0 }))}
                  className="flex-1 bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  placeholder="0"
                />
                <span className="text-gray-400">
                  {newMultiplier.multiplierType === 'percentage' ? '%' : 'pts'}
                </span>
              </div>
              
              <textarea
                value={newMultiplier.description}
                onChange={(e) => setNewMultiplier(prev => ({ ...prev, description: e.target.value }))}
                rows={1}
                className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
                placeholder="Descrição..."
              />
            </div>
            
            <button
              onClick={addVitalMultiplier}
              className="flex items-center space-x-2 px-4 py-2 bg-purple-700 hover:bg-purple-600 text-white rounded-lg transition-colors duration-200"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Multiplicador</span>
            </button>
          </div>

          {/* Lista de Multiplicadores */}
          {vitalMultipliers.length > 0 && (
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-red-100">Multiplicadores Ativos</h3>
              {vitalMultipliers.map((multiplier, index) => (
                <div key={index} className={`bg-gray-800 rounded-lg p-4 border-2 transition-all duration-200 ${
                  multiplier.isActive ? 'border-purple-600 bg-purple-900/10' : 'border-gray-700'
                }`}>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <h4 className="text-md font-bold text-red-100">{multiplier.name}</h4>
                      <span className="px-2 py-1 rounded-full text-xs font-medium bg-gray-700 text-gray-300">
                        {multiplier.targetVital.toUpperCase()}
                      </span>
                      <button
                        onClick={() => toggleVitalMultiplier(index)}
                        className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium transition-colors duration-200 ${
                          multiplier.isActive 
                            ? 'bg-purple-700 text-purple-100 hover:bg-purple-600' 
                            : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                        }`}
                      >
                        {multiplier.isActive ? <Power className="w-3 h-3" /> : <PowerOff className="w-3 h-3" />}
                        <span>{multiplier.isActive ? 'Ativo' : 'Inativo'}</span>
                      </button>
                    </div>
                    
                    <button
                      onClick={() => removeVitalMultiplier(index)}
                      className="text-red-400 hover:text-red-300 transition-colors duration-200"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-sm">
                    <div className="bg-gray-700 rounded p-2">
                      <div className="text-xs text-gray-400">Fonte</div>
                      <div className="text-gray-200">{multiplier.sourceTarget}</div>
                    </div>
                    
                    <div className="bg-gray-700 rounded p-2">
                      <div className="text-xs text-gray-400">Tipo</div>
                      <div className="text-gray-200">
                        {multiplier.multiplierType === 'percentage' ? 'Porcentagem' : 'Fixo'}
                      </div>
                    </div>
                    
                    <div className="bg-gray-700 rounded p-2">
                      <div className="text-xs text-gray-400">Valor</div>
                      <div className="text-purple-400 font-medium">
                        {multiplier.value}{multiplier.multiplierType === 'percentage' ? '%' : ' pts'}
                      </div>
                    </div>
                    
                    <div className="bg-gray-700 rounded p-2">
                      <div className="text-xs text-gray-400">Gasto</div>
                      <div className="text-gray-200">{multiplier.cost || 'Nenhum'}</div>
                    </div>
                  </div>
                  
                  {multiplier.description && (
                    <p className="text-gray-400 text-sm mt-2">{multiplier.description}</p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* HP - Pontos de Vida */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <div className="flex items-center space-x-3 mb-4">
          <Heart className="w-6 h-6 text-red-400" />
          <h3 className="text-xl font-bold text-red-100">Pontos de Vida (HP)</h3>
        </div>
        
        <div className="mb-4">
          <div className="text-sm text-gray-400 mb-2">
            Fórmula: 10 + Constituição ({attributes['Constituição']?.calculation.total || 0}) = {calculatedVitals.hp}
          </div>
          
          <div className="relative bg-gray-700 rounded-full h-6 mb-3">
            <div 
              className={`absolute top-0 left-0 h-full rounded-full transition-all duration-300 ${getBarColor(getPercentage(vitals.hp.current, vitals.hp.max), 'hp')}`}
              style={{ width: `${getPercentage(vitals.hp.current, vitals.hp.max)}%` }}
            />
            <div className="absolute inset-0 flex items-center justify-center text-white font-bold text-sm">
              {vitals.hp.current} / {vitals.hp.max}
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-xs text-gray-400 mb-1">Atual</label>
            <input
              type="number"
              value={vitals.hp.current}
              onChange={(e) => updateVital('hp', 'current', parseInt(e.target.value) || 0)}
              className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-center focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-xs text-gray-400 mb-1">Máximo</label>
            <input
              type="number"
              value={vitals.hp.max}
              onChange={(e) => updateVital('hp', 'max', parseInt(e.target.value) || 0)}
              className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-center focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
          </div>
        </div>
        
        <div className="flex justify-center space-x-2">
          <button
            onClick={() => adjustVital('hp', -1)}
            className="flex items-center justify-center w-10 h-10 bg-red-700 hover:bg-red-600 text-white rounded-lg transition-colors duration-200"
          >
            <Minus className="w-4 h-4" />
          </button>
          <button
            onClick={() => adjustVital('hp', -5)}
            className="px-3 py-2 bg-red-700 hover:bg-red-600 text-white rounded-lg transition-colors duration-200 text-sm"
          >
            -5
          </button>
          <button
            onClick={() => adjustVital('hp', 5)}
            className="px-3 py-2 bg-green-700 hover:bg-green-600 text-white rounded-lg transition-colors duration-200 text-sm"
          >
            +5
          </button>
          <button
            onClick={() => adjustVital('hp', 1)}
            className="flex items-center justify-center w-10 h-10 bg-green-700 hover:bg-green-600 text-white rounded-lg transition-colors duration-200"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Stamina */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <div className="flex items-center space-x-3 mb-4">
          <Zap className="w-6 h-6 text-blue-400" />
          <h3 className="text-xl font-bold text-red-100">Stamina</h3>
        </div>
        
        <div className="mb-4">
          <div className="text-sm text-gray-400 mb-2">
            Fórmula: 5 + Nível de Força ({attributes['Força']?.attributeLevel || 1}) = {calculatedVitals.stamina}
          </div>
          
          <div className="relative bg-gray-700 rounded-full h-6 mb-3">
            <div 
              className={`absolute top-0 left-0 h-full rounded-full transition-all duration-300 ${getBarColor(getPercentage(vitals.stamina.current, vitals.stamina.max), 'stamina')}`}
              style={{ width: `${getPercentage(vitals.stamina.current, vitals.stamina.max)}%` }}
            />
            <div className="absolute inset-0 flex items-center justify-center text-white font-bold text-sm">
              {vitals.stamina.current} / {vitals.stamina.max}
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-xs text-gray-400 mb-1">Atual</label>
            <input
              type="number"
              value={vitals.stamina.current}
              onChange={(e) => updateVital('stamina', 'current', parseInt(e.target.value) || 0)}
              className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-center focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-xs text-gray-400 mb-1">Máximo</label>
            <input
              type="number"
              value={vitals.stamina.max}
              onChange={(e) => updateVital('stamina', 'max', parseInt(e.target.value) || 0)}
              className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-center focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
          </div>
        </div>
        
        <div className="flex justify-center space-x-2">
          <button
            onClick={() => adjustVital('stamina', -1)}
            className="flex items-center justify-center w-10 h-10 bg-red-700 hover:bg-red-600 text-white rounded-lg transition-colors duration-200"
          >
            <Minus className="w-4 h-4" />
          </button>
          <button
            onClick={() => adjustVital('stamina', -5)}
            className="px-3 py-2 bg-red-700 hover:bg-red-600 text-white rounded-lg transition-colors duration-200 text-sm"
          >
            -5
          </button>
          <button
            onClick={() => adjustVital('stamina', 5)}
            className="px-3 py-2 bg-green-700 hover:bg-green-600 text-white rounded-lg transition-colors duration-200 text-sm"
          >
            +5
          </button>
          <button
            onClick={() => adjustVital('stamina', 1)}
            className="flex items-center justify-center w-10 h-10 bg-green-700 hover:bg-green-600 text-white rounded-lg transition-colors duration-200"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Mana */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <div className="flex items-center space-x-3 mb-4">
          <Sparkles className="w-6 h-6 text-purple-400" />
          <h3 className="text-xl font-bold text-red-100">Mana</h3>
        </div>
        
        <div className="mb-4">
          <div className="text-sm text-gray-400 mb-2">
            Fórmula: 5 + Nível de Magia ({attributes['Magia']?.attributeLevel || 1}) = {calculatedVitals.mana}
          </div>
          
          <div className="relative bg-gray-700 rounded-full h-6 mb-3">
            <div 
              className={`absolute top-0 left-0 h-full rounded-full transition-all duration-300 ${getBarColor(getPercentage(vitals.mana.current, vitals.mana.max), 'mana')}`}
              style={{ width: `${getPercentage(vitals.mana.current, vitals.mana.max)}%` }}
            />
            <div className="absolute inset-0 flex items-center justify-center text-white font-bold text-sm">
              {vitals.mana.current} / {vitals.mana.max}
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-xs text-gray-400 mb-1">Atual</label>
            <input
              type="number"
              value={vitals.mana.current}
              onChange={(e) => updateVital('mana', 'current', parseInt(e.target.value) || 0)}
              className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-center focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-xs text-gray-400 mb-1">Máximo</label>
            <input
              type="number"
              value={vitals.mana.max}
              onChange={(e) => updateVital('mana', 'max', parseInt(e.target.value) || 0)}
              className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-center focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
          </div>
        </div>
        
        <div className="flex justify-center space-x-2">
          <button
            onClick={() => adjustVital('mana', -1)}
            className="flex items-center justify-center w-10 h-10 bg-red-700 hover:bg-red-600 text-white rounded-lg transition-colors duration-200"
          >
            <Minus className="w-4 h-4" />
          </button>
          <button
            onClick={() => adjustVital('mana', -5)}
            className="px-3 py-2 bg-red-700 hover:bg-red-600 text-white rounded-lg transition-colors duration-200 text-sm"
          >
            -5
          </button>
          <button
            onClick={() => adjustVital('mana', 5)}
            className="px-3 py-2 bg-green-700 hover:bg-green-600 text-white rounded-lg transition-colors duration-200 text-sm"
          >
            +5
          </button>
          <button
            onClick={() => adjustVital('mana', 1)}
            className="flex items-center justify-center w-10 h-10 bg-green-700 hover:bg-green-600 text-white rounded-lg transition-colors duration-200"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Sanidade */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <div className="flex items-center space-x-3 mb-4">
          <Brain className="w-6 h-6 text-indigo-400" />
          <h3 className="text-xl font-bold text-red-100">Sanidade</h3>
        </div>
        
        <div className="mb-4">
          <div className="text-sm text-gray-400 mb-2">
            Fórmula: 20 + Nível de Inteligência ({attributes['Inteligência']?.attributeLevel || 1}) = {calculatedVitals.sanity}
            {vitalMultipliers.filter(m => m.isActive && m.targetVital === 'sanity').length > 0 && (
              <span className="text-green-400 ml-2">
                (+{calculatedVitals.sanity - (20 + (attributes['Inteligência']?.attributeLevel || 1))} bônus)
              </span>
            )}
          </div>
          
          <div className="relative bg-gray-700 rounded-full h-6 mb-3">
            <div 
              className={`absolute top-0 left-0 h-full rounded-full transition-all duration-300 ${getBarColor(getPercentage(vitals.sanity.current, vitals.sanity.max), 'sanity')}`}
              style={{ width: `${getPercentage(vitals.sanity.current, vitals.sanity.max)}%` }}
            />
            <div className="absolute inset-0 flex items-center justify-center text-white font-bold text-sm">
              {vitals.sanity.current} / {vitals.sanity.max}
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-xs text-gray-400 mb-1">Atual</label>
            <input
              type="number"
              value={vitals.sanity.current}
              onChange={(e) => updateVital('sanity', 'current', parseInt(e.target.value) || 0)}
              className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-center focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-xs text-gray-400 mb-1">Máximo</label>
            <input
              type="number"
              value={vitals.sanity.max}
              onChange={(e) => updateVital('sanity', 'max', parseInt(e.target.value) || 0)}
              className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-center focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
          </div>
        </div>
        
        <div className="flex justify-center space-x-2">
          <button
            onClick={() => adjustVital('sanity', -1)}
            className="flex items-center justify-center w-10 h-10 bg-red-700 hover:bg-red-600 text-white rounded-lg transition-colors duration-200"
          >
            <Minus className="w-4 h-4" />
          </button>
          <button
            onClick={() => adjustVital('sanity', -5)}
            className="px-3 py-2 bg-red-700 hover:bg-red-600 text-white rounded-lg transition-colors duration-200 text-sm"
          >
            -5
          </button>
          <button
            onClick={() => adjustVital('sanity', 5)}
            className="px-3 py-2 bg-green-700 hover:bg-green-600 text-white rounded-lg transition-colors duration-200 text-sm"
          >
            +5
          </button>
          <button
            onClick={() => adjustVital('sanity', 1)}
            className="flex items-center justify-center w-10 h-10 bg-green-700 hover:bg-green-600 text-white rounded-lg transition-colors duration-200"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};