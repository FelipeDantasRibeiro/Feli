import React, { useState } from 'react';
import { Plus, Trash2, Book } from 'lucide-react';

interface KnowledgeTabProps {
  knowledge: string[];
  onUpdateKnowledge: (knowledge: string[]) => void;
}

export const KnowledgeTab: React.FC<KnowledgeTabProps> = ({ knowledge, onUpdateKnowledge }) => {
  const [newKnowledge, setNewKnowledge] = useState('');

  const addKnowledge = () => {
    if (newKnowledge.trim()) {
      onUpdateKnowledge([...knowledge, newKnowledge.trim()]);
      setNewKnowledge('');
    }
  };

  const removeKnowledge = (index: number) => {
    onUpdateKnowledge(knowledge.filter((_, i) => i !== index));
  };

  const updateKnowledge = (index: number, value: string) => {
    const updated = knowledge.map((item, i) => i === index ? value : item);
    onUpdateKnowledge(updated);
  };

  return (
    <div className="space-y-6">
      {/* Adicionar Novo Conhecimento */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-bold text-red-100 mb-4">Adicionar Conhecimento</h3>
        
        <div className="flex space-x-4">
          <input
            type="text"
            value={newKnowledge}
            onChange={(e) => setNewKnowledge(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addKnowledge()}
            className="flex-1 bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
            placeholder="Ex: História Antiga, Ocultismo, Medicina..."
          />
          
          <button
            onClick={addKnowledge}
            className="flex items-center space-x-2 px-4 py-2 bg-red-700 hover:bg-red-600 text-white rounded-lg transition-colors duration-200"
          >
            <Plus className="w-4 h-4" />
            <span>Adicionar</span>
          </button>
        </div>
      </div>

      {/* Lista de Conhecimentos */}
      {knowledge.length === 0 ? (
        <div className="bg-gray-800 rounded-lg p-12 border border-gray-700 text-center">
          <Book className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-300 mb-2">Nenhum conhecimento adicionado</h3>
          <p className="text-gray-500">
            Adicione conhecimentos, especializações e áreas de estudo do seu personagem.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {knowledge.map((item, index) => (
            <div key={index} className="bg-gray-800 rounded-lg p-4 border border-gray-700 group hover:border-red-800 transition-all duration-200">
              <div className="flex items-center justify-between">
                <input
                  type="text"
                  value={item}
                  onChange={(e) => updateKnowledge(index, e.target.value)}
                  className="flex-1 bg-transparent text-gray-200 font-medium focus:outline-none focus:text-red-200"
                />
                
                <button
                  onClick={() => removeKnowledge(index)}
                  className="opacity-0 group-hover:opacity-100 text-red-400 hover:text-red-300 transition-all duration-200 ml-2"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};