import React, { useState } from 'react';
import { Character, CharacterAttribute, Skill, ActiveAbility, VitalMultiplier } from '../../types/character';
import { DEFAULT_ATTRIBUTES, DEFAULT_SKILLS } from '../../data/diceLevels';
import { calculateAttribute, getAttributeLevelFromValue, getDiceFromValue, calculateCharacterLevel } from '../../utils/attributeUtils';
import { AttributeCard } from '../AttributeCard/AttributeCard';
import { SkillsTab } from './SkillsTab';
import { AbilitiesTab } from './AbilitiesTab';
import { KnowledgeTab } from './KnowledgeTab';
import { VitalsTab } from './VitalsTab';
import { Save, ArrowLeft } from 'lucide-react';
import { calculateVitals } from '../../utils/attributeUtils';

interface CharacterFormProps {
  character?: Character;
  onSave: (character: Omit<Character, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onCancel: () => void;
}

export const CharacterForm: React.FC<CharacterFormProps> = ({ character, onSave, onCancel }) => {
  const [activeTab, setActiveTab] = useState<'attributes' | 'vitals' | 'skills' | 'abilities' | 'knowledge'>('attributes');
  
  const [formData, setFormData] = useState({
    name: character?.name || '',
    imageUrl: character?.imageUrl || '',
    campaign: character?.campaign || '',
    race: character?.race || '',
    clan: character?.clan || '',
    element: character?.element || '',
    notes: character?.notes || '',
  });

  const [attributes, setAttributes] = useState<Record<string, CharacterAttribute>>(() => {
    if (character?.attributes) return character.attributes;
    
    const defaultAttrs: Record<string, CharacterAttribute> = {};
    DEFAULT_ATTRIBUTES.forEach(name => {
      const calculation = calculateAttribute(10, 0, 0);
      defaultAttrs[name] = {
        name,
        calculation,
        dice: getDiceFromValue(calculation.total),
        attributeLevel: getAttributeLevelFromValue(calculation.total)
      };
    });
    return defaultAttrs;
  });

  const [skills, setSkills] = useState<Skill[]>(() => {
    if (character?.skills) return character.skills;
    
    return DEFAULT_SKILLS.map(skill => ({
      name: skill.name,
      baseAttribute: skill.baseAttribute,
      bonus: 0,
      total: attributes[skill.baseAttribute]?.calculation.total || 0
    }));
  });

  const [activeAbilities, setActiveAbilities] = useState<ActiveAbility[]>(
    character?.activeAbilities || []
  );
  
  const [multiplierAbilities, setMultiplierAbilities] = useState<MultiplierAbility[]>(
    character?.multiplierAbilities || []
  );
  
  const [vitalMultipliers, setVitalMultipliers] = useState<VitalMultiplier[]>(
    character?.vitalMultipliers || []
  );

  const [knowledge, setKnowledge] = useState<string[]>(
    character?.knowledge || []
  );
  
  const [vitals, setVitals] = useState(() => {
    if (character?.vitals) return character.vitals;
    
    const calculatedVitals = calculateVitals(attributes, skills, vitalMultipliers);
    return {
      hp: { current: calculatedVitals.hp, max: calculatedVitals.hp },
      stamina: { current: calculatedVitals.stamina, max: calculatedVitals.stamina },
      mana: { current: calculatedVitals.mana, max: calculatedVitals.mana },
      sanity: { current: calculatedVitals.sanity, max: calculatedVitals.sanity }
    };
  });

  const characterLevel = calculateCharacterLevel(attributes);

  const handleSave = () => {
    if (!formData.name.trim()) return;
    
    onSave({
      ...formData,
      attributes,
      vitals,
      skills,
      activeAbilities,
      multiplierAbilities,
      vitalMultipliers,
      knowledge,
      characterLevel,
    });
  };

  const updateAttribute = (name: string, updates: Partial<CharacterAttribute>) => {
    setAttributes(prev => {
      const newAttributes = {
        ...prev,
        [name]: { ...prev[name], ...updates }
      };
      
      // Atualizar skills baseadas neste atributo
      setSkills(prevSkills => 
        prevSkills.map(skill => 
          skill.baseAttribute === name 
            ? { ...skill, total: (newAttributes[name]?.calculation.total || 0) + skill.bonus }
            : skill
        )
      );
      
      return newAttributes;
    });
  };

  const tabs = [
    { id: 'attributes', label: 'Atributos', count: Object.keys(attributes).length },
    { id: 'vitals', label: 'Vitais', count: 4 },
    { id: 'skills', label: 'Perícias', count: skills.length },
    { id: 'abilities', label: 'Habilidades', count: activeAbilities.length + multiplierAbilities.length },
    { id: 'knowledge', label: 'Conhecimentos', count: knowledge.length },
  ];

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <button
              onClick={onCancel}
              className="flex items-center space-x-2 px-4 py-2 bg-gray-700 hover:bg-gray-600 text-gray-300 rounded-lg transition-colors duration-200"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Voltar</span>
            </button>
            <div>
              <h1 className="text-3xl font-bold text-red-100">
                {character ? 'Editar Personagem' : 'Novo Personagem'}
              </h1>
              <p className="text-gray-400">Nível do Personagem: {characterLevel}</p>
            </div>
          </div>
          
          <button
            onClick={handleSave}
            disabled={!formData.name.trim()}
            className="flex items-center space-x-2 px-6 py-3 bg-red-700 hover:bg-red-600 disabled:bg-gray-600 text-white rounded-lg font-semibold transition-all duration-200 disabled:cursor-not-allowed"
          >
            <Save className="w-4 h-4" />
            <span>Salvar</span>
          </button>
        </div>

        {/* Informações Básicas */}
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700 mb-8">
          <h2 className="text-xl font-bold text-red-100 mb-4">Informações Básicas</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Nome do Personagem
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder="Digite o nome..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Campanha
              </label>
              <input
                type="text"
                value={formData.campaign}
                onChange={(e) => setFormData(prev => ({ ...prev, campaign: e.target.value }))}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder="Nome da campanha..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                URL da Imagem
              </label>
              <input
                type="url"
                value={formData.imageUrl}
                onChange={(e) => setFormData(prev => ({ ...prev, imageUrl: e.target.value }))}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder="https://exemplo.com/imagem.jpg"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Raça
              </label>
              <input
                type="text"
                value={formData.race}
                onChange={(e) => setFormData(prev => ({ ...prev, race: e.target.value }))}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder="Ex: Humano, Elfo, Anão..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Clã
              </label>
              <input
                type="text"
                value={formData.clan}
                onChange={(e) => setFormData(prev => ({ ...prev, clan: e.target.value }))}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder="Ex: Uchiha, Senju..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Elemento
              </label>
              <input
                type="text"
                value={formData.element}
                onChange={(e) => setFormData(prev => ({ ...prev, element: e.target.value }))}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder="Ex: Fogo, Água, Terra..."
              />
            </div>
          </div>
          
          {/* Preview da Imagem */}
          {formData.imageUrl && (
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Preview da Imagem
              </label>
              <div className="flex justify-center">
                <img
                  src={formData.imageUrl}
                  alt="Preview do personagem"
                  className="w-32 h-32 object-cover rounded-lg border-2 border-gray-600"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                  }}
                />
              </div>
            </div>
          )}
          
          <div className="mt-4">
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Anotações
            </label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
              rows={3}
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
              placeholder="História, personalidade, objetivos..."
            />
          </div>
        </div>

        {/* Tabs */}
        <div className="mb-8">
          <div className="border-b border-gray-700">
            <nav className="flex space-x-8">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors duration-200 ${
                    activeTab === tab.id
                      ? 'border-red-500 text-red-400'
                      : 'border-transparent text-gray-400 hover:text-gray-300 hover:border-gray-300'
                  }`}
                >
                  {tab.label}
                  <span className="ml-2 bg-gray-700 text-gray-300 py-1 px-2 rounded-full text-xs">
                    {tab.count}
                  </span>
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Tab Content */}
        <div>
          {activeTab === 'attributes' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Object.entries(attributes).map(([name, attribute]) => (
                <AttributeCard
                  key={name}
                  attribute={attribute}
                  onUpdate={(updates) => updateAttribute(name, updates)}
                />
              ))}
            </div>
          )}

          {activeTab === 'vitals' && (
            <VitalsTab
              attributes={attributes}
              skills={skills}
              vitals={vitals}
              vitalMultipliers={vitalMultipliers}
              onUpdateVitals={setVitals}
              onUpdateVitalMultipliers={setVitalMultipliers}
            />
          )}

          {activeTab === 'skills' && (
            <SkillsTab
              skills={skills}
              attributes={attributes}
              onUpdateSkills={setSkills}
            />
          )}

          {activeTab === 'abilities' && (
            <AbilitiesTab
              activeAbilities={activeAbilities}
              multiplierAbilities={multiplierAbilities}
              attributes={attributes}
              onUpdateActiveAbilities={setActiveAbilities}
              onUpdateMultiplierAbilities={setMultiplierAbilities}
              onUpdateAttributes={setAttributes}
            />
          )}

          {activeTab === 'knowledge' && (
            <KnowledgeTab
              knowledge={knowledge}
              onUpdateKnowledge={setKnowledge}
            />
          )}
        </div>
      </div>
    </div>
  );
};