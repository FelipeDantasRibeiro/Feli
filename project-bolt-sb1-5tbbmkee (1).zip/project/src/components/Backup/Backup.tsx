import React, { useRef } from 'react';
import { Download, Upload, FileText, AlertCircle } from 'lucide-react';

interface BackupProps {
  onExport: () => void;
  onImport: (file: File) => void;
  charactersCount: number;
}

export const Backup: React.FC<BackupProps> = ({ onExport, onImport, charactersCount }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onImport(file);
    }
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-red-100 mb-2">Sistema de Backup</h1>
          <p className="text-gray-400">Mantenha suas fichas seguras com backups regulares</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Exportar Fichas */}
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <div className="flex items-center space-x-3 mb-4">
              <Download className="w-6 h-6 text-green-400" />
              <h2 className="text-xl font-bold text-red-100">Exportar Fichas</h2>
            </div>
            
            <p className="text-gray-400 mb-6">
              Baixe todas as suas fichas em um arquivo JSON para backup seguro.
            </p>
            
            <div className="bg-gray-700 rounded-lg p-4 mb-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <FileText className="w-5 h-5 text-gray-400" />
                  <span className="text-gray-300">Fichas disponíveis</span>
                </div>
                <span className="text-2xl font-bold text-green-400">{charactersCount}</span>
              </div>
            </div>
            
            <button
              onClick={onExport}
              disabled={charactersCount === 0}
              className="w-full flex items-center justify-center space-x-2 py-3 px-4 bg-green-700 hover:bg-green-600 disabled:bg-gray-600 text-white rounded-lg font-semibold transition-all duration-200 disabled:cursor-not-allowed"
            >
              <Download className="w-5 h-5" />
              <span>{charactersCount === 0 ? 'Nenhuma ficha para exportar' : 'Baixar Backup'}</span>
            </button>
          </div>

          {/* Importar Fichas */}
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <div className="flex items-center space-x-3 mb-4">
              <Upload className="w-6 h-6 text-blue-400" />
              <h2 className="text-xl font-bold text-red-100">Importar Fichas</h2>
            </div>
            
            <p className="text-gray-400 mb-6">
              Restaure suas fichas a partir de um arquivo de backup JSON.
            </p>
            
            <div className="bg-yellow-900/20 border border-yellow-600/30 rounded-lg p-4 mb-6">
              <div className="flex items-start space-x-3">
                <AlertCircle className="w-5 h-5 text-yellow-400 mt-0.5 flex-shrink-0" />
                <div className="text-sm">
                  <p className="text-yellow-400 font-medium mb-1">Atenção</p>
                  <p className="text-yellow-200">
                    As fichas importadas serão adicionadas às existentes. 
                    Certifique-se de que o arquivo está no formato correto.
                  </p>
                </div>
              </div>
            </div>
            
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleFileSelect}
              className="hidden"
            />
            
            <button
              onClick={handleImportClick}
              className="w-full flex items-center justify-center space-x-2 py-3 px-4 bg-blue-700 hover:bg-blue-600 text-white rounded-lg font-semibold transition-all duration-200"
            >
              <Upload className="w-5 h-5" />
              <span>Selecionar Arquivo</span>
            </button>
          </div>
        </div>

        {/* Dicas de Backup */}
        <div className="mt-8 bg-gray-800 rounded-lg p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-red-100 mb-4">Dicas de Backup</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium text-gray-300 mb-2">Frequência Recomendada</h4>
              <ul className="text-sm text-gray-400 space-y-1">
                <li>• Após criar novas fichas importantes</li>
                <li>• Antes de grandes mudanças no sistema</li>
                <li>• Semanalmente para campanhas ativas</li>
                <li>• Mensalmente para fichas arquivadas</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium text-gray-300 mb-2">Armazenamento Seguro</h4>
              <ul className="text-sm text-gray-400 space-y-1">
                <li>• Salve em múltiplos locais</li>
                <li>• Use nuvem (Google Drive, Dropbox)</li>
                <li>• Mantenha cópias offline</li>
                <li>• Teste regularmente a restauração</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};