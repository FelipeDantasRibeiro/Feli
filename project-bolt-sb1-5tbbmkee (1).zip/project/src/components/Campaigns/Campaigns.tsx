import React, { useState } from 'react';
import { Campaign, CampaignLink } from '../../types/character';
import { Plus, Trash2, ExternalLink, CreditCard as Edit, Save, X, MapPin, FileText, Link, Globe } from 'lucide-react';

interface CampaignsProps {
  campaigns: Campaign[];
  onAddCampaign: (campaign: Omit<Campaign, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onUpdateCampaign: (id: string, updates: Partial<Campaign>) => void;
  onDeleteCampaign: (id: string) => void;
}

export const Campaigns: React.FC<CampaignsProps> = ({
  campaigns,
  onAddCampaign,
  onUpdateCampaign,
  onDeleteCampaign,
}) => {
  const [showForm, setShowForm] = useState(false);
  const [editingCampaign, setEditingCampaign] = useState<Campaign | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    masterName: '',
    notes: '',
  });

  const [newLink, setNewLink] = useState({
    title: '',
    url: '',
    description: '',
    type: 'document' as CampaignLink['type'],
  });

  const resetForm = () => {
    setFormData({ name: '', description: '', masterName: '', notes: '' });
    setNewLink({ title: '', url: '', description: '', type: 'document' });
    setShowForm(false);
    setEditingCampaign(null);
  };

  const handleSubmit = () => {
    if (!formData.name.trim()) return;

    const campaignData = {
      ...formData,
      links: editingCampaign?.links || [],
    };

    if (editingCampaign) {
      onUpdateCampaign(editingCampaign.id, campaignData);
    } else {
      onAddCampaign(campaignData);
    }

    resetForm();
  };

  const handleEdit = (campaign: Campaign) => {
    setEditingCampaign(campaign);
    setFormData({
      name: campaign.name,
      description: campaign.description,
      masterName: campaign.masterName,
      notes: campaign.notes,
    });
    setShowForm(true);
  };

  const addLink = () => {
    if (!newLink.title.trim() || !newLink.url.trim() || !editingCampaign) return;

    const link: CampaignLink = {
      id: crypto.randomUUID(),
      ...newLink,
    };

    const updatedLinks = [...(editingCampaign.links || []), link];
    onUpdateCampaign(editingCampaign.id, { links: updatedLinks });
    
    setEditingCampaign({ ...editingCampaign, links: updatedLinks });
    setNewLink({ title: '', url: '', description: '', type: 'document' });
  };

  const removeLink = (linkId: string) => {
    if (!editingCampaign) return;

    const updatedLinks = editingCampaign.links.filter(link => link.id !== linkId);
    onUpdateCampaign(editingCampaign.id, { links: updatedLinks });
    setEditingCampaign({ ...editingCampaign, links: updatedLinks });
  };

  const getLinkIcon = (type: CampaignLink['type']) => {
    switch (type) {
      case 'document': return FileText;
      case 'map': return MapPin;
      case 'reference': return Link;
      default: return Globe;
    }
  };

  const getLinkTypeLabel = (type: CampaignLink['type']) => {
    switch (type) {
      case 'document': return 'Documento';
      case 'map': return 'Mapa';
      case 'reference': return 'Referência';
      default: return 'Outro';
    }
  };

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-red-100 mb-2">Campanhas</h1>
            <p className="text-gray-400">Gerencie campanhas e recursos para os jogadores</p>
          </div>
          
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center space-x-2 px-6 py-3 bg-red-700 hover:bg-red-600 text-white rounded-lg font-semibold transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            <Plus className="w-5 h-5" />
            <span>Nova Campanha</span>
          </button>
        </div>

        {/* Formulário */}
        {showForm && (
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700 mb-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-red-100">
                {editingCampaign ? 'Editar Campanha' : 'Nova Campanha'}
              </h2>
              <button
                onClick={resetForm}
                className="text-gray-400 hover:text-gray-300"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Nome da Campanha
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  placeholder="Ex: A Lenda do Dragão Negro"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Nome do Mestre
                </label>
                <input
                  type="text"
                  value={formData.masterName}
                  onChange={(e) => setFormData(prev => ({ ...prev, masterName: e.target.value }))}
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  placeholder="Seu nome"
                />
              </div>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Descrição
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                rows={3}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
                placeholder="Descrição da campanha, ambientação, regras especiais..."
              />
            </div>

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Anotações do Mestre
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                rows={3}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
                placeholder="Anotações privadas, NPCs importantes, plot hooks..."
              />
            </div>

            {/* Links da Campanha */}
            {editingCampaign && (
              <div className="mb-6">
                <h3 className="text-lg font-bold text-red-100 mb-4">Links e Recursos</h3>
                
                {/* Adicionar Link */}
                <div className="bg-gray-700 rounded-lg p-4 mb-4">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mb-3">
                    <input
                      type="text"
                      value={newLink.title}
                      onChange={(e) => setNewLink(prev => ({ ...prev, title: e.target.value }))}
                      className="bg-gray-600 border border-gray-500 rounded px-3 py-2 text-white text-sm focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      placeholder="Título do link"
                    />
                    
                    <input
                      type="url"
                      value={newLink.url}
                      onChange={(e) => setNewLink(prev => ({ ...prev, url: e.target.value }))}
                      className="bg-gray-600 border border-gray-500 rounded px-3 py-2 text-white text-sm focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      placeholder="https://..."
                    />
                    
                    <select
                      value={newLink.type}
                      onChange={(e) => setNewLink(prev => ({ ...prev, type: e.target.value as CampaignLink['type'] }))}
                      className="bg-gray-600 border border-gray-500 rounded px-3 py-2 text-white text-sm focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    >
                      <option value="document">Documento</option>
                      <option value="map">Mapa</option>
                      <option value="reference">Referência</option>
                      <option value="other">Outro</option>
                    </select>
                    
                    <button
                      onClick={addLink}
                      className="flex items-center justify-center px-3 py-2 bg-green-700 hover:bg-green-600 text-white rounded text-sm transition-colors duration-200"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <input
                    type="text"
                    value={newLink.description}
                    onChange={(e) => setNewLink(prev => ({ ...prev, description: e.target.value }))}
                    className="w-full bg-gray-600 border border-gray-500 rounded px-3 py-2 text-white text-sm focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    placeholder="Descrição do link (opcional)"
                  />
                </div>

                {/* Lista de Links */}
                {editingCampaign.links && editingCampaign.links.length > 0 && (
                  <div className="space-y-2">
                    {editingCampaign.links.map((link) => {
                      const IconComponent = getLinkIcon(link.type);
                      return (
                        <div key={link.id} className="flex items-center justify-between bg-gray-700 rounded-lg p-3">
                          <div className="flex items-center space-x-3 flex-1">
                            <IconComponent className="w-4 h-4 text-gray-400" />
                            <div className="flex-1">
                              <div className="flex items-center space-x-2">
                                <span className="text-white font-medium">{link.title}</span>
                                <span className="text-xs bg-gray-600 text-gray-300 px-2 py-1 rounded">
                                  {getLinkTypeLabel(link.type)}
                                </span>
                              </div>
                              {link.description && (
                                <p className="text-sm text-gray-400 mt-1">{link.description}</p>
                              )}
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-2">
                            <a
                              href={link.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-400 hover:text-blue-300 transition-colors duration-200"
                            >
                              <ExternalLink className="w-4 h-4" />
                            </a>
                            <button
                              onClick={() => removeLink(link.id)}
                              className="text-red-400 hover:text-red-300 transition-colors duration-200"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            <div className="flex space-x-4">
              <button
                onClick={handleSubmit}
                disabled={!formData.name.trim()}
                className="flex items-center space-x-2 px-6 py-3 bg-red-700 hover:bg-red-600 disabled:bg-gray-600 text-white rounded-lg font-semibold transition-colors duration-200 disabled:cursor-not-allowed"
              >
                <Save className="w-4 h-4" />
                <span>{editingCampaign ? 'Salvar Alterações' : 'Criar Campanha'}</span>
              </button>
              
              <button
                onClick={resetForm}
                className="px-6 py-3 bg-gray-700 hover:bg-gray-600 text-gray-300 rounded-lg font-semibold transition-colors duration-200"
              >
                Cancelar
              </button>
            </div>
          </div>
        )}

        {/* Lista de Campanhas */}
        {campaigns.length === 0 ? (
          <div className="bg-gray-800 rounded-lg p-12 border border-gray-700 text-center">
            <MapPin className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-300 mb-2">Nenhuma campanha criada</h3>
            <p className="text-gray-500 mb-6">
              Crie sua primeira campanha para organizar recursos e links para os jogadores.
            </p>
            <button
              onClick={() => setShowForm(true)}
              className="inline-flex items-center space-x-2 px-6 py-3 bg-red-700 hover:bg-red-600 text-white rounded-lg font-semibold transition-colors duration-200"
            >
              <Plus className="w-5 h-5" />
              <span>Criar Primeira Campanha</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {campaigns.map((campaign) => (
              <div key={campaign.id} className="bg-gray-800 rounded-lg p-6 border border-gray-700 hover:border-red-800 transition-all duration-200">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-red-100 mb-1">{campaign.name}</h3>
                    <p className="text-sm text-gray-400">Mestre: {campaign.masterName}</p>
                  </div>
                  
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleEdit(campaign)}
                      className="p-2 text-gray-400 hover:text-blue-400 hover:bg-blue-900/20 rounded-lg transition-all duration-200"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        if (window.confirm('Tem certeza que deseja excluir esta campanha?')) {
                          onDeleteCampaign(campaign.id);
                        }
                      }}
                      className="p-2 text-gray-400 hover:text-red-400 hover:bg-red-900/20 rounded-lg transition-all duration-200"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {campaign.description && (
                  <p className="text-gray-300 mb-4">{campaign.description}</p>
                )}

                {/* Links da Campanha */}
                {campaign.links && campaign.links.length > 0 && (
                  <div className="mb-4">
                    <h4 className="text-sm font-medium text-gray-400 mb-2">Recursos Disponíveis</h4>
                    <div className="space-y-2">
                      {campaign.links.map((link) => {
                        const IconComponent = getLinkIcon(link.type);
                        return (
                          <div key={link.id} className="flex items-center justify-between bg-gray-700 rounded p-2">
                            <div className="flex items-center space-x-2">
                              <IconComponent className="w-4 h-4 text-gray-400" />
                              <span className="text-sm text-gray-300">{link.title}</span>
                            </div>
                            <a
                              href={link.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-400 hover:text-blue-300 transition-colors duration-200"
                            >
                              <ExternalLink className="w-4 h-4" />
                            </a>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                <div className="text-xs text-gray-500 pt-4 border-t border-gray-700">
                  Criada em {new Date(campaign.createdAt).toLocaleDateString('pt-BR')}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};