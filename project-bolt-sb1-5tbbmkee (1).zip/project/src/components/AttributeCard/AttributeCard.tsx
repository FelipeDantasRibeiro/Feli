import React, { useState } from 'react';
import { Dices, Target } from 'lucide-react';
import { CharacterAttribute, TestResult } from '../../types/character';
import { calculateAttribute, getAttributeLevelFromValue, getDiceFromValue, rollAttributeTest } from '../../utils/attributeUtils';

interface AttributeCardProps {
  attribute: CharacterAttribute;
  onUpdate: (updates: Partial<CharacterAttribute>) => void;
}

export const AttributeCard: React.FC<AttributeCardProps> = ({ attribute, onUpdate }) => {
  const [testResult, setTestResult] = useState<TestResult | null>(null);
  const [isRolling, setIsRolling] = useState(false);

  const handleBaseValueChange = (value: number) => {
    const newCalculation = calculateAttribute(
      value,
      attribute.calculation.standardMultiplier,
      attribute.calculation.abilityMultiplier
    );
    
    const newAttributeLevel = getAttributeLevelFromValue(newCalculation.total);
    const newDice = getDiceFromValue(newCalculation.total);
    
    onUpdate({
      calculation: newCalculation,
      attributeLevel: newAttributeLevel,
      dice: newDice
    });
  };

  const handleMultiplierChange = (type: 'standard' | 'ability', value: number) => {
    const newCalculation = calculateAttribute(
      attribute.calculation.baseValue,
      type === 'standard' ? value : attribute.calculation.standardMultiplier,
      type === 'ability' ? value : attribute.calculation.abilityMultiplier
    );
    
    const newAttributeLevel = getAttributeLevelFromValue(newCalculation.total);
    const newDice = getDiceFromValue(newCalculation.total);
    
    onUpdate({
      calculation: newCalculation,
      attributeLevel: newAttributeLevel,
      dice: newDice
    });
  };

  const handleTest = async () => {
    setIsRolling(true);
    
    // Animação de rolagem
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const result = rollAttributeTest(attribute.calculation.total, attribute.dice);
    setTestResult(result);
    setIsRolling(false);
  };

  const getResultColor = (level: TestResult['level']) => {
    switch (level) {
      case 'critical': return 'text-yellow-400';
      case 'extreme': return 'text-green-400';
      case 'good': return 'text-blue-400';
      case 'normal': return 'text-gray-300';
      case 'failure': return 'text-red-400';
      case 'extreme_failure': return 'text-red-600';
      default: return 'text-gray-300';
    }
  };

  const getResultText = (level: TestResult['level']) => {
    switch (level) {
      case 'critical': return 'CRÍTICO';
      case 'extreme': return 'EXTREMO';
      case 'good': return 'BOM';
      case 'normal': return 'SUCESSO';
      case 'failure': return 'FALHA';
      case 'extreme_failure': return 'FALHA EXTREMA';
      default: return '';
    }
  };

  return (
    <div className="bg-gray-800 rounded-lg p-6 shadow-lg border border-gray-700 hover:border-red-800 transition-all duration-200">
      {/* Área do Título */}
      <div className="text-center mb-6">
        <h3 className="text-2xl font-bold text-red-100 mb-2">{attribute.name}</h3>
        <div className="text-sm text-gray-400">
          Nível {attribute.attributeLevel} • {attribute.dice}
        </div>
      </div>

      {/* Exibição Principal */}
      <div className="bg-gray-900 rounded-lg p-4 mb-6 text-center">
        <div className="mb-3">
          <div className="text-sm text-gray-400 mb-1">Valor Total</div>
          <div className="text-4xl font-bold text-red-400 font-mono">
            {attribute.calculation.total}
          </div>
        </div>
      </div>

      {/* Área de Teste */}
      <div className="mb-6">
        <button
          onClick={handleTest}
          disabled={isRolling}
          className={`w-full flex items-center justify-center space-x-3 py-4 px-4 rounded-lg font-bold text-lg transition-all duration-200 ${
            isRolling
              ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
              : 'bg-blue-700 hover:bg-blue-600 text-blue-100 hover:shadow-lg transform hover:scale-105'
          }`}
        >
          <Target className={`w-6 h-6 ${isRolling ? 'animate-spin' : ''}`} />
          <span>{isRolling ? 'Testando...' : 'Fazer Teste'}</span>
        </button>

        {/* Resultado do Teste */}
        {testResult && (
          <div className="mt-4 p-4 bg-gray-900 rounded-lg">
            <div className="text-center">
              <div className="text-sm text-gray-400 mb-2">Resultado do Teste</div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-300">Rolagem:</span>
                <span className="font-mono text-xl">{testResult.roll}</span>
              </div>
              <div className="flex justify-between items-center mb-3">
                <span className="text-gray-300">Alvo:</span>
                <span className="font-mono text-xl">{testResult.target}</span>
              </div>
              <div className={`text-lg font-bold ${getResultColor(testResult.level)}`}>
                {getResultText(testResult.level)}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Área de Cálculo */}
      <div className="border-t border-gray-700 pt-6">
        <h4 className="text-sm font-medium text-gray-300 mb-4 text-center">Configuração do Atributo</h4>
        
        <div className="grid grid-cols-2 gap-4">
          {/* Valor Base */}
          <div>
            <label className="block text-xs text-gray-400 mb-1">Valor Base</label>
            <input
              type="number"
              value={attribute.calculation.baseValue}
              onChange={(e) => handleBaseValueChange(parseInt(e.target.value) || 0)}
              className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-center font-mono focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
          </div>
          
          {/* Mult. Padrão */}
          <div>
            <label className="block text-xs text-gray-400 mb-1">Mult. Padrão (%)</label>
            <input
              type="number"
              value={attribute.calculation.standardMultiplier}
              onChange={(e) => handleMultiplierChange('standard', parseInt(e.target.value) || 0)}
              className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-center focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
          </div>
          
          {/* Mult. Habilidade */}
          <div>
            <label className="block text-xs text-gray-400 mb-1">Mult. Habilidade (%)</label>
            <input
              type="number"
              value={attribute.calculation.abilityMultiplier}
              onChange={(e) => handleMultiplierChange('ability', parseInt(e.target.value) || 0)}
              className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-center focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
          </div>
          
          {/* Atributo Total */}
          <div>
            <label className="block text-xs text-gray-400 mb-1">Total Final</label>
            <div className="w-full bg-red-900/30 border-2 border-red-600 rounded px-3 py-2 text-red-300 text-center font-mono font-bold text-lg">
              {attribute.calculation.total}
            </div>
          </div>
        </div>

        {/* Fórmula de Cálculo */}
        <div className="mt-4 p-3 bg-gray-900 rounded text-xs text-gray-400">
          <div className="text-center">
            <span className="text-gray-300">Cálculo:</span> {attribute.calculation.baseValue} 
            → +{attribute.calculation.standardMultiplier}% 
            → +{attribute.calculation.abilityMultiplier}% 
            = <span className="text-red-400 font-bold">{attribute.calculation.total}</span>
          </div>
        </div>
      </div>
    </div>
  );
};