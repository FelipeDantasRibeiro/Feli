import React from 'react';
import { AppSettings } from '../../types/character';
import { Palette, Type, Monitor, Save, Check, Skull, Moon, Sun } from 'lucide-react';

interface SettingsProps {
  settings: AppSettings;
  onUpdateSettings: (settings: Partial<AppSettings>) => void;
}

export const Settings: React.FC<SettingsProps> = ({ settings, onUpdateSettings }) => {
  const handleThemeChange = (theme: 'dark' | 'light') => {
    onUpdateSettings({ theme });
  };

  const handleColorChange = (color: string) => {
    onUpdateSettings({ primaryColor: color });
  };

  const handleFontSizeChange = (fontSize: 'small' | 'medium' | 'large') => {
    onUpdateSettings({ fontSize });
  };

  return (
    <div className={`min-h-screen py-8 transition-all duration-300 ${
      settings.theme === 'dark' 
        ? 'bg-gradient-to-br from-black via-gray-900 to-gray-800' 
        : 'bg-gradient-to-br from-gray-100 via-white to-gray-200'
    }`}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="flex items-center space-x-3 mb-4">
            <Skull className="w-8 h-8 text-red-600" />
            <h1 className={`text-4xl font-bold font-serif ${
              settings.theme === 'dark' ? 'text-red-100' : 'text-gray-900'
            }`}>
              Configurações de Aparência
            </h1>
          </div>
          <p className={`${settings.theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
            Personalize a atmosfera sombria do sistema
          </p>
        </div>

        <div className="space-y-8">
          {/* Tema */}
          <div className={`rounded-xl p-8 border-2 shadow-2xl transition-all duration-300 ${
            settings.theme === 'dark' 
              ? 'bg-gray-900/50 border-gray-700/50 backdrop-blur-sm' 
              : 'bg-white/80 border-gray-300/50 backdrop-blur-sm'
          }`}>
            <div className="flex items-center space-x-3 mb-6">
              <Monitor className={`w-6 h-6 ${settings.theme === 'dark' ? 'text-blue-400' : 'text-blue-600'}`} />
              <h2 className={`text-2xl font-bold font-serif ${
                settings.theme === 'dark' ? 'text-red-100' : 'text-gray-900'
              }`}>
                Tema da Interface
              </h2>
            </div>
            
            <div className="grid grid-cols-2 gap-6">
              <button
                onClick={() => handleThemeChange('dark')}
                className={`p-6 rounded-xl border-3 transition-all duration-300 transform hover:scale-105 relative ${
                  settings.theme === 'dark'
                    ? 'border-red-600 bg-red-900/30 shadow-xl'
                    : settings.theme === 'dark' 
                      ? 'border-gray-600 bg-gray-800/50 hover:border-gray-500'
                      : 'border-gray-300 bg-gray-100/50 hover:border-gray-400'
                }`}
              >
                {settings.theme === 'dark' && (
                  <div className="absolute top-3 right-3">
                    <Check className="w-5 h-5 text-red-400" />
                  </div>
                )}
                <div className="flex items-center justify-center mb-4">
                  <Moon className="w-8 h-8 text-gray-300" />
                </div>
                <div className="bg-gray-900 rounded-lg p-4 mb-4 border border-red-900/50">
                  <div className="bg-red-800 h-3 rounded mb-2"></div>
                  <div className="bg-gray-700 h-2 rounded mb-2"></div>
                  <div className="bg-gray-600 h-2 rounded"></div>
                </div>
                <p className={`text-lg font-semibold ${
                  settings.theme === 'dark' ? 'text-gray-200' : 'text-gray-700'
                }`}>
                  Sombrio (Berserk)
                </p>
                <p className={`text-sm ${
                  settings.theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
                }`}>
                  Atmosfera medieval dark
                </p>
              </button>
              
              <button
                onClick={() => handleThemeChange('light')}
                className={`p-6 rounded-xl border-3 transition-all duration-300 transform hover:scale-105 relative ${
                  settings.theme === 'light'
                    ? 'border-red-600 bg-red-900/30 shadow-xl'
                    : settings.theme === 'dark'
                      ? 'border-gray-600 bg-gray-800/50 hover:border-gray-500'
                      : 'border-gray-300 bg-gray-100/50 hover:border-gray-400'
                }`}
              >
                {settings.theme === 'light' && (
                  <div className="absolute top-3 right-3">
                    <Check className="w-5 h-5 text-red-400" />
                  </div>
                )}
                <div className="flex items-center justify-center mb-4">
                  <Sun className="w-8 h-8 text-yellow-500" />
                </div>
                <div className="bg-gray-100 rounded-lg p-4 mb-4 border border-red-600/30">
                  <div className="bg-red-600 h-3 rounded mb-2"></div>
                  <div className="bg-gray-300 h-2 rounded mb-2"></div>
                  <div className="bg-gray-400 h-2 rounded"></div>
                </div>
                <p className={`text-lg font-semibold ${
                  settings.theme === 'dark' ? 'text-gray-200' : 'text-gray-700'
                }`}>
                  Claro
                </p>
                <p className={`text-sm ${
                  settings.theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
                }`}>
                  Interface luminosa
                </p>
              </button>
            </div>
          </div>

          {/* Cor Principal */}
          <div className={`rounded-xl p-8 border-2 shadow-2xl transition-all duration-300 ${
            settings.theme === 'dark' 
              ? 'bg-gray-900/50 border-gray-700/50 backdrop-blur-sm' 
              : 'bg-white/80 border-gray-300/50 backdrop-blur-sm'
          }`}>
            <div className="flex items-center space-x-3 mb-6">
              <Palette className={`w-6 h-6 ${settings.theme === 'dark' ? 'text-purple-400' : 'text-purple-600'}`} />
              <h2 className={`text-2xl font-bold font-serif ${
                settings.theme === 'dark' ? 'text-red-100' : 'text-gray-900'
              }`}>
                Cor de Destaque
              </h2>
            </div>
            
            <div className="grid grid-cols-3 md:grid-cols-6 gap-4">
              {[
                { name: 'Vermelho Sangue', color: '#8B0000' },
                { name: 'Carmesim Profundo', color: '#DC143C' },
                { name: 'Dourado Antigo', color: '#B8860B' },
                { name: 'Roxo Místico', color: '#663399' },
                { name: 'Azul Aço', color: '#4682B4' },
                { name: 'Verde Sombrio', color: '#228B22' },
                { name: 'Laranja Fogo', color: '#FF4500' },
                { name: 'Rosa Sombrio', color: '#8B008B' },
              ].map((colorOption) => (
                <button
                  key={colorOption.color}
                  onClick={() => handleColorChange(colorOption.color)}
                  className={`aspect-square rounded-xl border-3 transition-all duration-300 transform hover:scale-110 relative shadow-lg ${
                    settings.primaryColor === colorOption.color
                      ? 'border-white scale-110 shadow-2xl'
                      : settings.theme === 'dark'
                        ? 'border-gray-600 hover:border-gray-400'
                        : 'border-gray-300 hover:border-gray-500'
                  }`}
                  style={{ backgroundColor: colorOption.color }}
                  title={colorOption.name}
                >
                  {settings.primaryColor === colorOption.color && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Check className="w-6 h-6 text-white drop-shadow-2xl" />
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Tamanho da Fonte */}
          <div className={`rounded-xl p-8 border-2 shadow-2xl transition-all duration-300 ${
            settings.theme === 'dark' 
              ? 'bg-gray-900/50 border-gray-700/50 backdrop-blur-sm' 
              : 'bg-white/80 border-gray-300/50 backdrop-blur-sm'
          }`}>
            <div className="flex items-center space-x-3 mb-6">
              <Type className={`w-6 h-6 ${settings.theme === 'dark' ? 'text-green-400' : 'text-green-600'}`} />
              <h2 className={`text-2xl font-bold font-serif ${
                settings.theme === 'dark' ? 'text-red-100' : 'text-gray-900'
              }`}>
                Tamanho da Fonte
              </h2>
            </div>
            
            <div className="grid grid-cols-3 gap-6">
              {[
                { id: 'small', label: 'Pequena', example: 'Texto compacto', size: 'text-sm' },
                { id: 'medium', label: 'Média', example: 'Texto padrão', size: 'text-base' },
                { id: 'large', label: 'Grande', example: 'Texto ampliado', size: 'text-lg' }
              ].map((size) => (
                <button
                  key={size.id}
                  onClick={() => handleFontSizeChange(size.id as any)}
                  className={`p-6 rounded-xl border-3 transition-all duration-300 transform hover:scale-105 relative ${
                    settings.fontSize === size.id
                      ? 'border-red-600 bg-red-900/30 shadow-xl'
                      : settings.theme === 'dark'
                        ? 'border-gray-600 bg-gray-800/50 hover:border-gray-500'
                        : 'border-gray-300 bg-gray-100/50 hover:border-gray-400'
                  }`}
                >
                  {settings.fontSize === size.id && (
                    <div className="absolute top-3 right-3">
                      <Check className="w-5 h-5 text-red-400" />
                    </div>
                  )}
                  <p className={`font-bold mb-3 ${size.size} ${
                    settings.theme === 'dark' ? 'text-gray-200' : 'text-gray-700'
                  }`}>
                    {size.label}
                  </p>
                  <p className={`${size.size} ${
                    settings.theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                  }`}>
                    {size.example}
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* Outras Configurações */}
          <div className={`rounded-xl p-8 border-2 shadow-2xl transition-all duration-300 ${
            settings.theme === 'dark' 
              ? 'bg-gray-900/50 border-gray-700/50 backdrop-blur-sm' 
              : 'bg-white/80 border-gray-300/50 backdrop-blur-sm'
          }`}>
            <div className="flex items-center space-x-3 mb-6">
              <Save className={`w-6 h-6 ${settings.theme === 'dark' ? 'text-yellow-400' : 'text-yellow-600'}`} />
              <h2 className={`text-2xl font-bold font-serif ${
                settings.theme === 'dark' ? 'text-red-100' : 'text-gray-900'
              }`}>
                Configurações Gerais
              </h2>
            </div>
            
            <div className="space-y-6">
              <div className="flex items-center justify-between p-4 rounded-lg bg-gray-800/30">
                <div>
                  <p className={`font-semibold text-lg ${
                    settings.theme === 'dark' ? 'text-gray-200' : 'text-gray-700'
                  }`}>
                    Backup Automático
                  </p>
                  <p className={`text-sm ${
                    settings.theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                  }`}>
                    Salva automaticamente as alterações nas fichas
                  </p>
                </div>
                <button
                  onClick={() => onUpdateSettings({ autoBackup: !settings.autoBackup })}
                  className={`relative inline-flex h-8 w-14 items-center rounded-full transition-colors duration-300 ${
                    settings.autoBackup ? 'bg-red-600' : 'bg-gray-600'
                  }`}
                >
                  <span
                    className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform duration-300 ${
                      settings.autoBackup ? 'translate-x-7' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Preview das Configurações */}
        <div className={`mt-8 rounded-xl p-8 border-2 shadow-2xl transition-all duration-300 ${
          settings.theme === 'dark' 
            ? 'bg-gray-900/50 border-gray-700/50 backdrop-blur-sm' 
            : 'bg-white/80 border-gray-300/50 backdrop-blur-sm'
        }`}>
          <h3 className={`text-2xl font-bold font-serif mb-6 ${
            settings.theme === 'dark' ? 'text-red-100' : 'text-gray-900'
          }`}>
            Preview da Interface
          </h3>
          
          <div className={`rounded-xl p-6 border-2 ${
            settings.theme === 'dark' ? 'bg-gray-800/50 border-gray-700' : 'bg-gray-100/50 border-gray-300'
          }`}>
            <div 
              className="h-4 rounded-lg mb-4 shadow-lg"
              style={{ backgroundColor: settings.primaryColor }}
            />
            <h4 className={`font-bold mb-3 font-serif ${
              settings.theme === 'dark' ? 'text-red-100' : 'text-gray-900'
            } ${
              settings.fontSize === 'small' ? 'text-xl' :
              settings.fontSize === 'medium' ? 'text-2xl' : 'text-3xl'
            }`}>
              Ragnar, o Berserker
            </h4>
            <p className={`${
              settings.theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
            } ${
              settings.fontSize === 'small' ? 'text-sm' :
              settings.fontSize === 'medium' ? 'text-base' : 'text-lg'
            }`}>
              Este é um exemplo de como o texto e os elementos aparecerão com as configurações atuais. 
              A atmosfera sombria de Berserk permeia toda a interface.
            </p>
            <div className="mt-4 flex space-x-3">
              <div 
                className="px-4 py-2 rounded-lg text-white font-semibold shadow-lg"
                style={{ backgroundColor: settings.primaryColor }}
              >
                Botão de Ação
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};