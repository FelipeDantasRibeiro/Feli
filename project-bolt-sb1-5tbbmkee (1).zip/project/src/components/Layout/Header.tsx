import React from 'react';
import { Sword, Users, Settings, FileText, Download, Skull } from 'lucide-react';
import { AppSettings } from '../../types/character';

interface HeaderProps {
  currentPage: string;
  onPageChange: (page: string) => void;
  settings: AppSettings;
}

export const Header: React.FC<HeaderProps> = ({ currentPage, onPageChange, settings }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Users },
    { id: 'characters', label: 'Fichas', icon: FileText },
    { id: 'campaigns', label: 'Campanhas', icon: Sword },
    { id: 'backup', label: 'Backup', icon: Download },
    { id: 'settings', label: 'Aparência', icon: Settings },
  ];

  return (
    <header className={`border-b-4 shadow-2xl transition-all duration-300 ${
      settings.theme === 'dark' 
        ? 'bg-black/90 backdrop-blur-sm border-red-900/50' 
        : 'bg-white/90 backdrop-blur-sm border-red-600/50'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Skull className="w-10 h-10 text-red-600 drop-shadow-lg" />
              <Sword className="w-6 h-6 absolute -top-1 -right-1" style={{ color: settings.primaryColor }} />
            </div>
            <div>
              <h1 className={`text-3xl font-bold tracking-wider font-serif ${
                settings.theme === 'dark' ? 'text-red-100 drop-shadow-lg' : 'text-gray-900'
              }`}>
                Grimório das Almas
              </h1>
              <p className={`text-xs tracking-widest ${
                settings.theme === 'dark' ? 'text-gray-500' : 'text-gray-600'
              }`}>
                SISTEMA DE FICHAS RPG
              </p>
            </div>
          </div>
          
          <nav className="flex space-x-2">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onPageChange(item.id)}
                className={`flex items-center space-x-2 px-6 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 ${
                 currentPage === item.id
                    ? `text-white shadow-xl border-2 border-opacity-50`
                    : settings.theme === 'dark'
                      ? 'text-gray-300 hover:bg-gray-800/50 hover:text-red-200 border-2 border-transparent'
                      : 'text-gray-600 hover:bg-gray-100/50 hover:text-red-600 border-2 border-transparent'
                }`}
                style={currentPage === item.id ? { 
                  backgroundColor: settings.primaryColor,
                  borderColor: settings.primaryColor + '80'
                } : {}}
              >
                <item.icon className="w-5 h-5" />
                <span className="hidden sm:inline font-medium">{item.label}</span>
              </button>
            ))}
          </nav>
        </div>
      </div>
    </header>
  );
};