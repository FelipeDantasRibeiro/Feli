import React from 'react';
import { Character } from '../../types/character';
import { CreditCard as Edit, Trash2, Calendar, MapPin, Users, Flame } from 'lucide-react';

interface CharacterCardProps {
  character: Character;
  onEdit: () => void;
  onDelete: () => void;
}

export const CharacterCard: React.FC<CharacterCardProps> = ({ character, onEdit, onDelete }) => {
  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('pt-BR');
  };

  const getTopAttributes = () => {
    return Object.values(character.attributes)
      .filter(attr => attr.calculation && typeof attr.calculation.total === 'number' && attr.attributeLevel)
      .sort((a, b) => b.attributeLevel - a.attributeLevel)
      .slice(0, 3);
  };

  const topAttributes = getTopAttributes();

  return (
    <div className="bg-gray-800 rounded-lg p-6 border border-gray-700 hover:border-red-800 transition-all duration-200 group">
      <div className="flex items-start justify-between mb-4">
        {/* Imagem do Personagem */}
        {character.imageUrl && (
          <div className="flex-shrink-0 mr-4">
            <img
              src={character.imageUrl}
              alt={character.name}
              className="w-16 h-16 object-cover rounded-lg border-2 border-gray-600"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
              }}
            />
          </div>
        )}
        
        <div className="flex-1">
          <h3 className="text-xl font-bold text-red-100 group-hover:text-red-200 transition-colors duration-200">
            {character.name}
          </h3>
          {character.campaign && (
            <div className="flex items-center space-x-1 mt-1">
              <MapPin className="w-3 h-3 text-gray-500" />
              <span className="text-sm text-gray-400">{character.campaign}</span>
            </div>
          )}

          {/* Raça, Clã e Elemento */}
          <div className="flex flex-wrap gap-2 mt-2">
            {character.race && (
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-900/30 text-blue-300 border border-blue-700/50">
                <Users className="w-3 h-3 mr-1" />
                {character.race}
              </span>
            )}
            {character.clan && (
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-900/30 text-green-300 border border-green-700/50">
                {character.clan}
              </span>
            )}
            {character.element && (
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-orange-900/30 text-orange-300 border border-orange-700/50">
                <Flame className="w-3 h-3 mr-1" />
                {character.element}
              </span>
            )}
          </div>
        </div>
        
        <div className="flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          <button
            onClick={onEdit}
            className="p-2 text-gray-400 hover:text-blue-400 hover:bg-blue-900/20 rounded-lg transition-all duration-200"
          >
            <Edit className="w-4 h-4" />
          </button>
          <button
            onClick={onDelete}
            className="p-2 text-gray-400 hover:text-red-400 hover:bg-red-900/20 rounded-lg transition-all duration-200"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Principais Atributos */}
      {topAttributes.length > 0 && (
        <div className="mb-4">
          <h4 className="text-sm font-medium text-gray-400 mb-2">Principais Atributos</h4>
          <div className="space-y-1">
            {topAttributes.map((attr) => (
              <div key={attr.name} className="flex justify-between items-center">
                <span className="text-sm text-gray-300">{attr.name}</span>
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-gray-500">Nv.{attr.attributeLevel}</span>
                  <span className="text-sm font-mono text-red-400">{attr.calculation.total}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Informações Adicionais */}
      <div className="text-xs text-gray-500 flex items-center justify-between pt-4 border-t border-gray-700">
        <div className="flex items-center space-x-1">
          <Calendar className="w-3 h-3" />
          <span>Atualizado em {formatDate(character.updatedAt)}</span>
        </div>
        <div className="text-right">
          <span>Nível {character.characterLevel}</span>
        </div>
      </div>
    </div>
  );
};