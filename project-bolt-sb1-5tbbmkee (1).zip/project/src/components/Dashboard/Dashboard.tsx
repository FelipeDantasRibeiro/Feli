import React from 'react';
import { Character } from '../../types/character';
import { Plus, Users, Calendar, Sword } from 'lucide-react';
import { CharacterCard } from './CharacterCard';

interface DashboardProps {
  characters: Character[];
  onCreateCharacter: () => void;
  onEditCharacter: (character: Character) => void;
  onDeleteCharacter: (id: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  characters,
  onCreateCharacter,
  onEditCharacter,
  onDeleteCharacter,
}) => {
  const recentCharacters = characters
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, 3);

  const campaignStats = characters.reduce((acc, char) => {
    acc[char.campaign] = (acc[char.campaign] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-red-100 mb-2">Dashboard</h1>
            <p className="text-gray-400">Gerencie suas fichas de personagem</p>
          </div>
          
          <button
            onClick={onCreateCharacter}
            className="flex items-center space-x-2 px-6 py-3 bg-red-700 hover:bg-red-600 text-white rounded-lg font-semibold transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            <Plus className="w-5 h-5" />
            <span>Nova Ficha</span>
          </button>
        </div>

        {/* Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <div className="flex items-center space-x-3">
              <Users className="w-8 h-8 text-red-400" />
              <div>
                <p className="text-2xl font-bold text-red-100">{characters.length}</p>
                <p className="text-gray-400">Total de Personagens</p>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <div className="flex items-center space-x-3">
              <Calendar className="w-8 h-8 text-red-400" />
              <div>
                <p className="text-2xl font-bold text-red-100">{Object.keys(campaignStats).length}</p>
                <p className="text-gray-400">Campanhas Ativas</p>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <div className="flex items-center space-x-3">
              <Sword className="w-8 h-8 text-red-400" />
              <div>
                <p className="text-2xl font-bold text-red-100">{recentCharacters.length}</p>
                <p className="text-gray-400">Fichas Recentes</p>
              </div>
            </div>
          </div>
        </div>

        {characters.length === 0 ? (
          <div className="bg-gray-800 rounded-lg p-12 border border-gray-700 text-center">
            <Users className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-300 mb-2">Nenhuma ficha criada</h3>
            <p className="text-gray-500 mb-6">
              Comece criando sua primeira ficha de personagem para suas aventuras épicas.
            </p>
            <button
              onClick={onCreateCharacter}
              className="inline-flex items-center space-x-2 px-6 py-3 bg-red-700 hover:bg-red-600 text-white rounded-lg font-semibold transition-all duration-200"
            >
              <Plus className="w-5 h-5" />
              <span>Criar Primeira Ficha</span>
            </button>
          </div>
        ) : (
          <div className="space-y-8">
            {/* Fichas Recentes */}
            {recentCharacters.length > 0 && (
              <div>
                <h2 className="text-2xl font-bold text-red-100 mb-4">Fichas Recentes</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {recentCharacters.map((character) => (
                    <CharacterCard
                      key={character.id}
                      character={character}
                      onEdit={() => onEditCharacter(character)}
                      onDelete={() => onDeleteCharacter(character.id)}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Todas as Fichas */}
            <div>
              <h2 className="text-2xl font-bold text-red-100 mb-4">Todas as Fichas</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {characters.map((character) => (
                  <CharacterCard
                    key={character.id}
                    character={character}
                    onEdit={() => onEditCharacter(character)}
                    onDelete={() => onDeleteCharacter(character.id)}
                  />
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};