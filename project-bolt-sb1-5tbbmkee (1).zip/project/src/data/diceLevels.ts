import { DiceLevel } from '../types/character';

export const DICE_LEVELS: DiceLevel[] = [
  { level: 1, dice: '1d20', minRange: 1, maxRange: 17 },
  { level: 2, dice: '1d30', minRange: 18, maxRange: 27 },
  { level: 3, dice: '1d50', minRange: 28, maxRange: 47 },
  { level: 4, dice: '1d100', minRange: 48, maxRange: 95 },
  { level: 5, dice: '1d150', minRange: 96, maxRange: 143 },
  { level: 6, dice: '1d200', minRange: 144, maxRange: 190 },
  { level: 7, dice: '1d300', minRange: 191, maxRange: 280 },
  { level: 8, dice: '1d500', minRange: 281, maxRange: 470 },
  { level: 9, dice: '1d1000', minRange: 471, maxRange: 960 },
  { level: 10, dice: '1d1500', minRange: 961, maxRange: 1430 },
  { level: 11, dice: '1d2000', minRange: 1431, maxRange: 1900 },
  { level: 12, dice: '1d3000', minRange: 1901, maxRange: 2800 },
  { level: 13, dice: '1d5000', minRange: 2801, maxRange: 4700 },
  { level: 14, dice: '1d10000', minRange: 4701, maxRange: 9600 },
  { level: 15, dice: '1d15000', minRange: 9601, maxRange: 14300 },
  { level: 16, dice: '1d20000', minRange: 14301, maxRange: 19000 },
  { level: 17, dice: '1d30000', minRange: 19001, maxRange: 28000 },
  { level: 18, dice: '1d50000', minRange: 28001, maxRange: 47000 },
  { level: 19, dice: '1d100000', minRange: 47001, maxRange: 96000 },
  { level: 20, dice: '1d150000', minRange: 96001, maxRange: 143000 },
  { level: 21, dice: '1d200000', minRange: 143001, maxRange: 190000 },
  { level: 22, dice: '1d300000', minRange: 190001, maxRange: 280000 },
  { level: 23, dice: '1d500000', minRange: 280001, maxRange: 470000 },
  { level: 24, dice: '1d1000000', minRange: 470001, maxRange: 960000 },
];

export const DEFAULT_ATTRIBUTES = [
  'Força',
  'Destreza',
  'Constituição',
  'Inteligência',
  'Carisma',
  'Magia',
  'Ilusão'
];

export const DEFAULT_SKILLS = [
  { name: 'Atletismo', baseAttribute: 'Força' },
  { name: 'Furtividade', baseAttribute: 'Destreza' },
  { name: 'Resistência', baseAttribute: 'Constituição' },
  { name: 'Investigação', baseAttribute: 'Inteligência' },
  { name: 'Persuasão', baseAttribute: 'Carisma' },
  { name: 'Ocultismo', baseAttribute: 'Magia' },
  { name: 'Enganação', baseAttribute: 'Ilusão' },
];