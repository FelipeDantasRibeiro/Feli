export interface DiceLevel {
  level: number;
  dice: string;
  minRange: number;
  maxRange: number;
}

export interface AttributeCalculation {
  baseValue: number; // Pontos investidos
  standardMultiplier: number; // Baseado no valor base
  abilityMultiplier: number; // Baseado no multiplicador padrão
  total: number; // Valor final
}

export interface CharacterAttribute {
  name: string;
  calculation: AttributeCalculation;
  dice: string;
  attributeLevel: number;
}

export interface Skill {
  name: string;
  baseAttribute: string;
  bonus: number;
  total: number;
}

export interface ActiveAbility {
  name: string;
  description: string;
  cost: string;
  actionCost: string;
  type: 'active' | 'passive' | 'conditional';
  isActive: boolean;
}

export interface MultiplierAbility {
  name: string;
  description: string;
  cost: string;
  percentage: number;
  targetAttribute: string;
  isActive: boolean;
}

export interface VitalMultiplier {
  name: string;
  description: string;
  cost: string;
  targetVital: 'hp' | 'stamina' | 'mana' | 'sanity';
  multiplierType: 'percentage' | 'fixed';
  value: number;
  baseSource: 'skill' | 'attribute';
  sourceTarget: string; // Nome da perícia ou atributo
  isActive: boolean;
}

export interface Character {
  id: string;
  campaignId: string;
  userId?: string;
  name: string;
  imageUrl?: string;
  race?: string;
  clan?: string;
  element?: string;
  isPublic?: boolean;
  createdAt: string;
  updatedAt: string;
  attributes: Record<string, CharacterAttribute>;
  vitals: {
    hp: { current: number; max: number };
    stamina: { current: number; max: number };
    mana: { current: number; max: number };
    sanity: { current: number; max: number };
  };
  skills: Skill[];
  activeAbilities: ActiveAbility[];
  multiplierAbilities: MultiplierAbility[];
  vitalMultipliers: VitalMultiplier[];
  knowledge: string[];
  notes: string;
  characterLevel: number;
}

export interface TestResult {
  roll: number;
  target: number;
  success: boolean;
  level: 'critical' | 'extreme' | 'good' | 'normal' | 'failure' | 'extreme_failure';
}

export interface AppSettings {
  theme: 'dark' | 'light';
  primaryColor: string;
  fontSize: 'small' | 'medium' | 'large';
  autoBackup: boolean;
}

export interface Campaign {
  id: string;
  userId?: string;
  name: string;
  description: string;
  masterName: string;
  passwordHash?: string;
  links: CampaignLink[];
  notes: string;
  createdAt: string;
  updatedAt: string;
  characters?: Character[];
}

export interface CampaignLink {
  id: string;
  title: string;
  url: string;
  description: string;
  type: 'document' | 'map' | 'reference' | 'other';
}