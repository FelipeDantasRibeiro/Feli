import { useState, useEffect } from 'react';
import { Campaign, CampaignLink } from '../types/character';

const CAMPAIGNS_KEY = 'rpg-campaigns';

export const useCampaigns = () => {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem(CAMPAIGNS_KEY);
    if (saved) {
      setCampaigns(JSON.parse(saved));
    }
  }, []);

  const saveCampaigns = (camps: Campaign[]) => {
    setCampaigns(camps);
    localStorage.setItem(CAMPAIGNS_KEY, JSON.stringify(camps));
  };

  const addCampaign = (campaign: Omit<Campaign, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newCampaign: Campaign = {
      ...campaign,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    saveCampaigns([...campaigns, newCampaign]);
    return newCampaign;
  };

  const updateCampaign = (id: string, updates: Partial<Campaign>) => {
    const updated = campaigns.map(campaign => 
      campaign.id === id 
        ? { ...campaign, ...updates, updatedAt: new Date().toISOString() }
        : campaign
    );
    saveCampaigns(updated);
  };

  const deleteCampaign = (id: string) => {
    saveCampaigns(campaigns.filter(campaign => campaign.id !== id));
  };

  return {
    campaigns,
    addCampaign,
    updateCampaign,
    deleteCampaign,
  };
};