import { useState, useEffect } from 'react';
import { Character, VitalMultiplier } from '../types/character';
import { calculateCharacterLevel, calculateVitals } from '../utils/attributeUtils';

const STORAGE_KEY = 'rpg-characters';

export const useCharacters = () => {
  const [characters, setCharacters] = useState<Character[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      setCharacters(JSON.parse(saved));
    }
  }, []);

  const saveCharacters = (chars: Character[]) => {
    setCharacters(chars);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(chars));
  };

  const addCharacter = (character: Omit<Character, 'id' | 'createdAt' | 'updatedAt'>) => {
    // Garantir que vitals existam
    const vitals = character.vitals || (() => {
      const calculatedVitals = calculateVitals(
        character.attributes, 
        character.skills || [], 
        character.vitalMultipliers || []
      );
      return {
        hp: { current: calculatedVitals.hp, max: calculatedVitals.hp },
        stamina: { current: calculatedVitals.stamina, max: calculatedVitals.stamina },
        mana: { current: calculatedVitals.mana, max: calculatedVitals.mana },
        sanity: { current: calculatedVitals.sanity, max: calculatedVitals.sanity }
      };
    })();
    
    const newCharacter: Character = {
      ...character,
      vitals,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      characterLevel: calculateCharacterLevel(character.attributes),
      multiplierAbilities: character.multiplierAbilities || [],
      vitalMultipliers: character.vitalMultipliers || [],
    };
    saveCharacters([...characters, newCharacter]);
    return newCharacter;
  };

  const updateCharacter = (id: string, updates: Partial<Character>) => {
    const updated = characters.map(char => 
      char.id === id 
        ? { 
            ...char, 
            ...updates, 
            updatedAt: new Date().toISOString(),
            characterLevel: updates.attributes ? calculateCharacterLevel(updates.attributes) : char.characterLevel
          }
        : char
    );
    saveCharacters(updated);
  };

  const deleteCharacter = (id: string) => {
    saveCharacters(characters.filter(char => char.id !== id));
  };

  const exportCharacters = () => {
    const data = JSON.stringify(characters, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rpg-characters-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const importCharacters = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const imported = JSON.parse(e.target?.result as string);
        if (Array.isArray(imported)) {
          saveCharacters([...characters, ...imported]);
        }
      } catch (error) {
        console.error('Erro ao importar arquivo:', error);
      }
    };
    reader.readAsText(file);
  };

  return {
    characters,
    addCharacter,
    updateCharacter,
    deleteCharacter,
    exportCharacters,
    importCharacters,
  };
};