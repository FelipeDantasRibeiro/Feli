import { useState, useEffect } from 'react';
import { AppSettings } from '../types/character';

const SETTINGS_KEY = 'rpg-settings';

const defaultSettings: AppSettings = {
  theme: 'dark',
  primaryColor: '#8B0000',
  fontSize: 'medium',
  autoBackup: true,
};

export const useSettings = () => {
  const [settings, setSettings] = useState<AppSettings>(defaultSettings);

  useEffect(() => {
    const saved = localStorage.getItem(SETTINGS_KEY);
    if (saved) {
      setSettings({ ...defaultSettings, ...JSON.parse(saved) });
    }
  }, []);

  const updateSettings = (newSettings: Partial<AppSettings>) => {
    const updated = { ...settings, ...newSettings };
    setSettings(updated);
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(updated));
  };

  return { settings, updateSettings };
};