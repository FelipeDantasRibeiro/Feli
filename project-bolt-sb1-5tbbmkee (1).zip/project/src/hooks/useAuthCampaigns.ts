import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Campaign, Character } from '../types/character';
import { hashPassword } from '../utils/password';
import { useAuth } from '../contexts/AuthContext';

export const useAuthCampaigns = () => {
  const { user } = useAuth();
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchCampaigns = async () => {
    if (!user) {
      setCampaigns([]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('campaigns')
        .select(`
          *,
          characters (*)
        `)
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;

      const formattedCampaigns: Campaign[] = (data || []).map((campaign: any) => ({
        id: campaign.id,
        userId: campaign.user_id,
        name: campaign.name,
        description: campaign.description,
        masterName: campaign.master_name,
        passwordHash: campaign.password_hash,
        links: campaign.links || [],
        notes: campaign.notes,
        createdAt: campaign.created_at,
        updatedAt: campaign.updated_at,
        characters: (campaign.characters || []).map((char: any) => ({
          id: char.id,
          campaignId: char.campaign_id,
          userId: char.user_id,
          name: char.name,
          imageUrl: char.image_url,
          race: char.race,
          clan: char.clan,
          element: char.element,
          attributes: char.attributes,
          vitals: char.vitals,
          skills: char.skills,
          activeAbilities: char.active_abilities,
          multiplierAbilities: char.multiplier_abilities,
          vitalMultipliers: char.vital_multipliers,
          knowledge: char.knowledge,
          notes: char.notes,
          characterLevel: char.character_level,
          isPublic: char.is_public,
          createdAt: char.created_at,
          updatedAt: char.updated_at,
        }))
      }));

      setCampaigns(formattedCampaigns);
    } catch (err: any) {
      setError(err.message);
      console.error('Error fetching campaigns:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCampaigns();
  }, [user]);

  const addCampaign = async (campaign: Omit<Campaign, 'id' | 'createdAt' | 'updatedAt' | 'characters' | 'userId'>, password?: string) => {
    try {
      if (!user) throw new Error('User not authenticated');

      const passwordHash = password ? await hashPassword(password) : null;

      const { data, error: insertError } = await supabase
        .from('campaigns')
        .insert([
          {
            user_id: user.id,
            name: campaign.name,
            description: campaign.description,
            master_name: campaign.masterName,
            password_hash: passwordHash,
            links: campaign.links,
            notes: campaign.notes,
          }
        ])
        .select()
        .single();

      if (insertError) throw insertError;

      await fetchCampaigns();
      return data;
    } catch (err: any) {
      setError(err.message);
      console.error('Error adding campaign:', err);
      throw err;
    }
  };

  const updateCampaign = async (id: string, updates: Partial<Campaign>, newPassword?: string) => {
    try {
      const updateData: any = {};

      if (updates.name !== undefined) updateData.name = updates.name;
      if (updates.description !== undefined) updateData.description = updates.description;
      if (updates.masterName !== undefined) updateData.master_name = updates.masterName;
      if (updates.links !== undefined) updateData.links = updates.links;
      if (updates.notes !== undefined) updateData.notes = updates.notes;

      if (newPassword !== undefined) {
        updateData.password_hash = newPassword ? await hashPassword(newPassword) : null;
      }

      const { error: updateError } = await supabase
        .from('campaigns')
        .update(updateData)
        .eq('id', id);

      if (updateError) throw updateError;

      await fetchCampaigns();
    } catch (err: any) {
      setError(err.message);
      console.error('Error updating campaign:', err);
      throw err;
    }
  };

  const deleteCampaign = async (id: string) => {
    try {
      const { error: deleteError } = await supabase
        .from('campaigns')
        .delete()
        .eq('id', id);

      if (deleteError) throw deleteError;

      await fetchCampaigns();
    } catch (err: any) {
      setError(err.message);
      console.error('Error deleting campaign:', err);
      throw err;
    }
  };

  return {
    campaigns,
    loading,
    error,
    addCampaign,
    updateCampaign,
    deleteCampaign,
    refreshCampaigns: fetchCampaigns,
  };
};
