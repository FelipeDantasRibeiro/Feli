import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Character } from '../types/character';
import { useAuth } from '../contexts/AuthContext';

export const useAuthCharacters = (campaignId?: string) => {
  const { user } = useAuth();
  const [characters, setCharacters] = useState<Character[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchCharacters = async () => {
    if (!user) {
      setCharacters([]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      let query = supabase
        .from('characters')
        .select('*')
        .order('created_at', { ascending: false });

      if (campaignId) {
        query = query.eq('campaign_id', campaignId);
      }

      const { data, error: fetchError } = await query;

      if (fetchError) throw fetchError;

      const formattedCharacters: Character[] = (data || []).map((char: any) => ({
        id: char.id,
        campaignId: char.campaign_id,
        userId: char.user_id,
        name: char.name,
        imageUrl: char.image_url,
        race: char.race,
        clan: char.clan,
        element: char.element,
        attributes: char.attributes,
        vitals: char.vitals,
        skills: char.skills,
        activeAbilities: char.active_abilities,
        multiplierAbilities: char.multiplier_abilities,
        vitalMultipliers: char.vital_multipliers,
        knowledge: char.knowledge,
        notes: char.notes,
        characterLevel: char.character_level,
        isPublic: char.is_public,
        createdAt: char.created_at,
        updatedAt: char.updated_at,
      }));

      setCharacters(formattedCharacters);
    } catch (err: any) {
      setError(err.message);
      console.error('Error fetching characters:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCharacters();
  }, [campaignId, user]);

  const addCharacter = async (character: Omit<Character, 'id' | 'createdAt' | 'updatedAt' | 'userId'> & { isPublic?: boolean }) => {
    try {
      if (!user) throw new Error('User not authenticated');

      const { data, error: insertError } = await supabase
        .from('characters')
        .insert([
          {
            user_id: user.id,
            campaign_id: character.campaignId,
            name: character.name,
            image_url: character.imageUrl,
            race: character.race,
            clan: character.clan,
            element: character.element,
            attributes: character.attributes,
            vitals: character.vitals,
            skills: character.skills,
            active_abilities: character.activeAbilities,
            multiplier_abilities: character.multiplierAbilities,
            vital_multipliers: character.vitalMultipliers,
            knowledge: character.knowledge,
            notes: character.notes,
            character_level: character.characterLevel,
            is_public: character.isPublic ?? true,
          }
        ])
        .select()
        .single();

      if (insertError) throw insertError;

      await fetchCharacters();
      return data;
    } catch (err: any) {
      setError(err.message);
      console.error('Error adding character:', err);
      throw err;
    }
  };

  const updateCharacter = async (id: string, updates: Partial<Character> & { isPublic?: boolean }) => {
    try {
      const updateData: any = {};

      if (updates.name !== undefined) updateData.name = updates.name;
      if (updates.imageUrl !== undefined) updateData.image_url = updates.imageUrl;
      if (updates.race !== undefined) updateData.race = updates.race;
      if (updates.clan !== undefined) updateData.clan = updates.clan;
      if (updates.element !== undefined) updateData.element = updates.element;
      if (updates.attributes !== undefined) updateData.attributes = updates.attributes;
      if (updates.vitals !== undefined) updateData.vitals = updates.vitals;
      if (updates.skills !== undefined) updateData.skills = updates.skills;
      if (updates.activeAbilities !== undefined) updateData.active_abilities = updates.activeAbilities;
      if (updates.multiplierAbilities !== undefined) updateData.multiplier_abilities = updates.multiplierAbilities;
      if (updates.vitalMultipliers !== undefined) updateData.vital_multipliers = updates.vitalMultipliers;
      if (updates.knowledge !== undefined) updateData.knowledge = updates.knowledge;
      if (updates.notes !== undefined) updateData.notes = updates.notes;
      if (updates.characterLevel !== undefined) updateData.character_level = updates.characterLevel;
      if (updates.isPublic !== undefined) updateData.is_public = updates.isPublic;

      const { error: updateError } = await supabase
        .from('characters')
        .update(updateData)
        .eq('id', id);

      if (updateError) throw updateError;

      await fetchCharacters();
    } catch (err: any) {
      setError(err.message);
      console.error('Error updating character:', err);
      throw err;
    }
  };

  const deleteCharacter = async (id: string) => {
    try {
      const { error: deleteError } = await supabase
        .from('characters')
        .delete()
        .eq('id', id);

      if (deleteError) throw deleteError;

      await fetchCharacters();
    } catch (err: any) {
      setError(err.message);
      console.error('Error deleting character:', err);
      throw err;
    }
  };

  return {
    characters,
    loading,
    error,
    addCharacter,
    updateCharacter,
    deleteCharacter,
    refreshCharacters: fetchCharacters,
  };
};
